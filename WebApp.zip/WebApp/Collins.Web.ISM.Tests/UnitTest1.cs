﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Collins.Web.ISM.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
