  'use strict';
    $(document).ready(function() {
 dashboard();

 /*Counter Js Starts*/
$('.counter').counterUp({
    delay: 10,
    time: 400
});
/*Counter Js Ends*/

//  Resource bar
    $(".resource-barchart").sparkline([5, 6, 2, 4, 9, 1, 2, 8, 3, 6, 4,2,1,5], {
              type: 'bar',
              barWidth: '15px',
              height: '80px',
              barColor: '#fff',
            tooltipClassname:'abc'
          });

            function setHeight() {
                var $window = $(window);
                var windowHeight = $(window).height();
                if ($window.width() >= 320) {
                    $('.user-list').parent().parent().css('min-height', windowHeight);
                    $('.chat-window-inner-content').css('max-height', windowHeight);
                    $('.user-list').parent().parent().css('right', -300);
                }
            };
            setHeight();

            $(window).on('load',function() {
                setHeight();
            });
        });

 $(window).resize(function() {
        dashboard();
        //  Resource bar
    $(".resource-barchart").sparkline([5, 6, 2, 4, 9, 1, 2, 8, 3, 6, 4,2,1,5], {
              type: 'bar',
              barWidth: '15px',
              height: '80px',
              barColor: '#fff',
            tooltipClassname:'abc'
          });
    });

function dashboard(){

};

  Highcharts.chart('barchart', {
      title: {
          text: 'Monthly Average Part Numbers Generated'
      },
      subtitle: {
          text: ''
      },
      xAxis: {
          categories: [
              'Jan',
              'Feb',
              'Mar',
              'Apr',
              'May',
              'Jun',
              'Jul',
              'Aug',
              'Sep',
              'Oct',
              'Nov',
              'Dec'
          ],
          crosshair: true
      },
      yAxis: {
          min: 0,
          title: {
              text: 'Count'
          }
      },
      tooltip: {
          //headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
          //pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          //    '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
          //footerFormat: '</table>',
          shared: true,
          useHTML: true
      },
      plotOptions: {
          column: {
              pointPadding: 0.2,
              borderWidth: 0
          }
      },
      series: [{
          name: 'Single Ticket',
          data: [49, 71, 106, 129, 144, 176, 135, 148, 216, 194, 95, 54]

      }, {
          name: 'Multi Ticket',
          data: [83, 78, 98, 93, 106, 84, 105, 104, 91, 83, 106, 92]

      }, {
          name: 'Large Block Reserve',
          data: [48, 38, 39, 41, 47, 48, 59, 59, 52, 65, 59, 51]

      },
      //{
      //    name: 'Other HS Series',
      //    data: [42, 33, 34, 39, 52, 75, 57, 60, 47, 39, 46, 51]

      //}
      ]
      //{
      //    type: 'spline',
      //    name: 'Average',
      //    data: [3.5, 2.67, 3, 6.33, 3.33],
      //    marker: {
      //        lineWidth: 2,
      //        lineColor: Highcharts.getOptions().colors[3],
      //        fillColor: 'white'
      //    }
      //},
      //{
      //    type: 'pie',
      //    name: 'Total consumption',
      //    data: [{
      //        name: 'Jane',
      //        y: 13,
      //        color: '#f57c00'
      //    }, {
      //        name: 'John',
      //        y: 23,
      //        color:'#2BBBAD'
      //    }, {
      //        name: 'Joe',
      //        y: 19,
      //        color:'#39444e'
      //    }],
      //    center: [40, 20],
      //    size: 100,
      //    showInLegend: false,
      //    dataLabels: {
      //        enabled: false
      //    }
      //}
      
  });


  Highcharts.chart('piechart', {
      chart: {
          type: 'pie',
          options3d: {
              enabled: true,
              alpha: 45,
              beta: 0
          }
         //  backgroundColor:'#fff'
      },
      title: {
          text: 'Browser market shares at a specific website, 2014'
      },
      tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions: {
          pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              depth: 35,
              dataLabels: {
                  enabled: true,
                  format: '{point.name}'
              }
          }
      },
      series: [{
          type: 'pie',
          name: 'Browser share',
          data: [
              {
                 name: 'Firefox',
                 y: 40.0,
                 sliced: true,
                 selected: true,
                 color:'#2BBBAD'
              },
              {
                 name: 'IE',
                 y: 26.8,
                 color:'#39444e'
               },
              {
                  name: 'Chrome',
                  y: 12.8,
                  color:'#2196F3'
              },
              {
                 name: 'Safari',
                 y: 8.5,
                 color:'#3F729B'
              },
              {
                 name: 'Opera',
                 y: 6.2,
                 color:'#f57c00'
              },
              {
                 name: 'Others',
                 y: 5.7,
                 color:'#aa66cc'
              }
          ]
      }]
  });
