﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.Business.Dto
{
    public class ISMRequestUpdation
    {
        public int iWorkFlowID { get; set; }
        public int iIssueNumber { get; set; }
        public int iUserId { get; set; }
        public int iLastProcessedUser { get; set; }
        public int T_iAssignGroup { get; set; }
        public int T_iAssignTo { get; set; }
        public string T_vcComments { get; set; }
        public string[] vcFileName { get; set; }
        public string isLastCopy { get; set; }
        public string[] vbDocument { get; set; }
        public string iDocFlag { get; set; }
        public string[] iWorkFlowDispotionId { get; set; }
        public string[] vcDispositionTitle { get; set; }
        public string[] iAssignedGroup { get; set; }
        public string[] iAssignedTo { get; set; }

        public string[] iAssignedGroupText { get; set; }
        public string[] iAssignedToText { get; set; }

        public string[] vcComments { get; set; }
        public int iDispositionType { get; set; }
        public string[] vcCCEmail { get; set; }
        public string[] d_vcCCEmails { get; set; }
        public string[] group_ToEmail { get; set; }
        public string[] WFDId { get; set; }
        public string iAssignedGroupToText { get; set; }
        public string iAssignToText { get; set; }
        public string vcProductName { get; set; }
        public string vcPartNumberName { get; set; }
        public string vcCategoryName { get; set; }
        public string vcPriorityName { get; set; }
        public string vcIssueDescription { get; set; }
        public string T_iAssignGroupText { get; set; }
        public string T_iAssignToText { get; set; }
        public string T_vcCommentsText { get; set; }
        public string toMail { get; set; }
        public int iStatus { get; set; }
        public string appendedIssueNumber { get; set; }
        public string AssignedByText { get; set; }
        public string iStatusText { get; set; }
        public string vcSolutionForClosed { get; set; }
        public string vcCRCO_One { get; set; }
        public string vcCRCO_Two { get; set; }
        public string vcCRCO_Three { get; set; }
        public string vcCRCO_Four { get; set; }
        public string vcCRCO_Five { get; set; }
    }    
}
