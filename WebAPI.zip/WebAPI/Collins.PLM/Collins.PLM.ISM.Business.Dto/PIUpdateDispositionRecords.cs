﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.Business.Dto
{
    public class PIUpdateDispositionRecords
    {
        public int iAssignedTo { get; set; }
        public string iAssignedToText { get; set; }
        public int iAssignedGroup { get; set; }
        public string iAssignedGroupText { get; set; }
        public int MyProperty { get; set; }
        public int iStatus { get; set; }
        public int iLastProcessedBy { get; set; }
        public int iProcessedBy { get; set; }
        public int iIssueWFID { get; set; }
        public int iWorkFlowDisposition { get; set; }
        public string Comments { get; set; }
        public string[] vcFileName { get; set; }
        public string isLastCopy { get; set; }
        public string[] vbDocument { get; set; }
        public string iDocFlag { get; set; }
        public string[] vcCCEmail { get; set; }
        public string toMail { get; set; }
        public string iIssueNumber { get; set; }
        public string DisplayIssueNumber { get; set; }
        public string DisplayDispositionId { get; set; }
        public string EJWU { get; set; }
        public string iStatusText { get; set; }
        public string Initiator { get; set; }
        public string vcPartNumberName { get; set; }
        public int iUserId { get; set; }
        public string vcSolutionForClosed { get; set; }
        public string vcCRCO_One { get; set; }
        public string vcCRCO_Two { get; set; }
        public string vcCRCO_Three { get; set; }
        public string vcCRCO_Four { get; set; }
        public string vcCRCO_Five { get; set; }
    }
}
