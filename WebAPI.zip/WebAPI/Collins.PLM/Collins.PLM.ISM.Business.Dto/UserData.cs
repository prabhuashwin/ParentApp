﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.Business.Dto
{
    public class UserData
    {
        public string vcFirstName { get; set; }
        public string vcLastName { get; set; }
        public string vcWindowsId { get; set; }
        public string vcTitle { get; set; }
        public string vcGivenname { get; set; }
        public string vcEmail { get; set; }
        public string vcSamAccountName { get; set; }
        public int GroupPickList { get; set; }
        
        //Evacs
        public int iSBUId { get; set; }
        public int iVSId { get; set; }
    }

    public class IssueRequest
    {
        public int WorkFlowName { get; set; }
        public string QNNumber { get; set; }
        public string ECD { get; set; }
        public int ProductLine { get; set; }
        public int PartNumber { get; set; }
        public int Category { get; set; }
        public int Priority { get; set; }
        public int ActivityOwner { get; set; }
        public string IssueDescription { get; set; }
        public int AssignGroup { get; set; }
        public int AssignTo { get; set; }
        //public string iInsId { get; set; }
        public string[][] vcFileName { get; set; }
        public string isLastCopy { get; set; }
        public string[][] vbDocument { get; set; }
        public string iDocFlag { get; set; }
        public List<byte[]> filebytes { get; set; }

    }
}
