﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.Business.Dto
{
    public class Lov
    {
    }
    public class WFObj
    {
        public int iWorkFlowID { get; set; }
        public string vcWorkFlowName { get; set; }
        public int bStatus { get; set; }
        public int iVSId { get; set; }
        public int iUserId { get; set; }
    }

    public class DPObj
    {
        public int iDispositionTypeID { get; set; }
        public string vcDispositionName { get; set; }
        public DateTime dCreatedDate { get; set; }
        public string vcFirstName { get; set; }
        public int bStatus { get; set; }

        public int iUserId { get; set; }
    }

    public class CObj
    {

        public int iCategoryID { get; set; }
        public string vcCategoryName { get; set; }
        public DateTime dCreatedDate { get; set; }
        public string vcFirstName { get; set; }
        public int bIsActive { get; set; }
        public int iUserId { get; set; }
    }

    public class PRDObj
    {
        public int iProductLineID { get; set; }
        public string vcProductName { get; set; }
        public DateTime dCreatedDate { get; set; }
        public string vcFirstName { get; set; }
        public int bIsActive { get; set; }
        public int iUserId { get; set; }
        public int iCategoryID { get; set; }
        public int iVsId { get; set; }
        public int iVSId { get; set; }


    }

    public class PRIObj
    {
        public int iPriorityID { get; set; }
        public string vcPriorityName { get; set; }
        public DateTime dCreatedDate { get; set; }
        public string vcFirstName { get; set; }
        public int bIsActive { get; set; }
        public int iVSId { get; set; }
        public int iUserId { get; set; }
    }

    public class PNObj
    {
        public int iPartNumberID { get; set; }
        public string vcPartNumberName { get; set; }
        public DateTime dCreatedDate { get; set; }
        public string vcFirstName { get; set; }
        public int bIsActive { get; set; }
        public int iUserId { get; set; }
        public int iProductline { get; set; }
        public string vcPartDescription { get; set; }
        public string vcPartNumber { get; set; }
    }

    public class SObj
    {
        public int iStatusID { get; set; }
        public string vcStatusDescription { get; set; }
        public DateTime dCreatedDate { get; set; }
        public string vcFirstName { get; set; }
        public int bIsActive { get; set; }
        public int iUserId { get; set; }
    }
    public class GroupObj
    {
        public string vcGroupDescription { get; set; }
        public int bStatus { get; set; }
        public int iCreatedBy { get; set; }
        public int iVSId { get; set; }
        public int iSBUId { get; set; }
    }
}
