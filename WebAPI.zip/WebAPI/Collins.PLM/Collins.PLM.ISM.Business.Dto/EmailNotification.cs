﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    RequestController
* File Desc   :    This file contains code pertaining to deal with Application Request.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 25-NOv-2021         Venkataramana         Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using Collins.PLM.ISM.Business.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ISM.Business.Dto
{
    public class EmailNotification : INotification
    {
        //public void NotifyStakeHolder(long requestId, UnitOfWork unitofwork, NotificationType notificationtype)
        //{
        //    var currentUnit = (unitofwork as UnitOfWork);
        //}

        /// <summary>
        /// Sends the mail to User.
        /// </summary>
        /// <param name="replyto">The replyto.</param>
        /// <param name="toAddress">To address.</param>
        /// <param name="toCC">To cc.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="mailBody">The mail body.</param>
        /// <param name="isHtml">if set to <c>true</c> [is HTML].</param>
        public void SendMailToAdmin(string replyto, string toAddress, string toCC, string subject, string mailBody, bool isHtml)
        {
            try
            {
                MailAddress fromMailer = new MailAddress("ISM@utc.com", "Auto:ISM-Dashboard Tool");//FinanceGOSPA@utc.com

                SmtpClient client = new SmtpClient();
                client.Port = 25;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Host = "mailhub.utc.com";

                MailMessage mail = new MailMessage();
                mail.From = fromMailer;
                mail.Subject = subject;
                mail.IsBodyHtml = isHtml;
                mail.Body = mailBody;
                mail.To.Add(toAddress);

                if (toCC != null && toCC != "")
                    mail.CC.Add(toCC);
                if(replyto!="")
                    mail.ReplyToList.Add(replyto);
                
                client.Send(mail);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
               
            }
        }
    }
}
