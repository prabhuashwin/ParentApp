﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.Business.Dto
{
    public class DocResponse
    {
        public string vbDocument { get; set; }
        public string vcFileName { get; set; }
    }
}
