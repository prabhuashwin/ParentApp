﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.Business.Dto
{
    public class ISMRequestInitiation
    {
        public string vcQNNumber { get; set; }
        public int iUserId { get; set; }
        public string dECD { get; set; }
        public int iLastProcessedUser { get; set; }
        public int iWorkFlowName { get; set; }
        public int iProductline { get; set; }
        public int? iPartNumber { get; set; }
        public int? iCategory { get; set; }
        public int? iPriority { get; set; }
        public int iActivityOwner { get; set; }
        public string vcIssueDescription { get; set; }
        public int iAssignedGroupTo { get; set; }
        public int iAssignTo { get; set; }
        public string[] vcFileName { get; set; }
        public int isLastCopy { get; set; }
        public string[] vbDocument { get; set; }
        public int iDocFlag { get; set; }
        public string[] vcCCEmail { get; set; }

        public string iProductlineText { get; set; }
        public string iPartNumberText { get; set; }
        public string iCategoryText { get; set; }
        public string iPriorityText { get; set; }
        public string iAssignedGroupToText { get; set; }
        public string iAssignToText { get; set; }
        public string toMail { get; set; }
        public string vcPartDescription { get; set; }
        public string vcPCNNumber { get; set; }
        public string vcUserName { get; set; }

        public string vcIssueTitle { get; set; }
        public string vcSerialNumber { get; set; }
        public int iVSId { get; set; }
        public string vcOtherPartNumber { get; set; }
    }
}
