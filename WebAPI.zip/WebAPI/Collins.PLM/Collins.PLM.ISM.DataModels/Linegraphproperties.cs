﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.DataModels
{
    public class Linegraphproperties
    {
        public string productlist { get; set; }
        public string pnList { get; set; }
        public string Priority { get; set; }
        public string WFList { get; set; }
        public string DispositionList { get; set; }
        public int? Quarterwise { get; set; }
        public string dStartDate { get; set; }
        public string dEndDate { get; set; }
        public string Quarter { get; set; }
        public int iVSid { get; set; }
    }
}
