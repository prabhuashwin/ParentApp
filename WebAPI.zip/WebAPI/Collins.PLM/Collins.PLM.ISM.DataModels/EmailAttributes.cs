﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.DataModels
{
    public class EmailAttributes
    {
        public string requetor { get; set; }
        public string toAddress { get; set; }
        public string toCC { get; set; }
        public string centerMessage { get; set; }
        public string body { get; set; }
        public string subject { get; set; }
        public string[] AdminCCEmails { get; set; }
        public string text { get; set; }
    }
}
