﻿using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using Collins.PLM.Common.ExceptionHandler.Utilities;
using Collins.PLM.ISM.Business.Dto;
using Collins.PLM.ISM.Business.Interfaces;
using Collins.PLM.ISM.DataModels;
using ISM.Business.Dto;
using ISM.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ISM.Business
{
    public class UserManager : IRegistrationHandler
    {
        public string URLDashboard = System.Configuration.ConfigurationManager.AppSettings["URLDashboard"].ToString();
        public string ManageUserAccess = System.Configuration.ConfigurationManager.AppSettings["ManageUserAccess"].ToString();

        public string decryptedUser = System.Configuration.ConfigurationManager.AppSettings["decryptedUser"].ToString();
        public string decryptedDomain = System.Configuration.ConfigurationManager.AppSettings["decryptedDomain"].ToString();
        public string decryptedPassword = System.Configuration.ConfigurationManager.AppSettings["decryptedPassword"].ToString();
        public string FolderPath = System.Configuration.ConfigurationManager.AppSettings["FolderPath"].ToString();

        /// <summary>
        /// User DB
        /// </summary>
        public readonly UserDb UserDb;

        /// <summary>
        /// User Manager
        /// </summary>
        public UserManager()
        {
            this.UserDb = new UserDb();
        }
        /// <summary>
        /// UserRegistration
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        public OperationResult UserRegistration(UserData req)
        {
            if (req == null) throw new ArgumentNullException(nameof(req));
            try
            {
                var registrationUser = UserDb != null && UserDb.RegistrationUser(req);

                if (registrationUser == true)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User registered successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = true
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User registered Fail",
                        MCode = MessageCode.OperationFailed,
                        Data = false
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// CheckUserExistenceByWindowsId
        /// </summary>
        /// <param name="windowsId"></param>
        /// <returns></returns>
        public OperationResult CheckUserExistenceByWindowsId(string windowsId)
        {
            if (windowsId == null) throw new ArgumentNullException(nameof(windowsId));
            try
            {
                DataTable userDt = UserDb.CheckUserExistenceByWindowsId(windowsId);
                // var userDet = UtilityMethods.ConvertDataTable<usp_checkEmailExistance>(userDt);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Sam Account Details",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Sam Account details not found",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// CheckUserExistence
        /// </summary>
        /// <param name="ldapUid"></param>
        /// <returns></returns>
        public OperationResult CheckUserExistence(string ldapUid)
        {
            if (ldapUid == null) throw new ArgumentNullException(nameof(ldapUid));
            try
            {
                var userDt = UserDb.CheckUserExistence(ldapUid);
                // var userDet = UtilityMethods.ConvertDataTable<usp_checkEmailExistance>(userDt);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Menu List Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Menu List Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetSamAccountNameByEmail
        /// </summary>
        /// <param name="vcEmail"></param>
        /// <returns></returns>
        public OperationResult GetSamAccountNameByEmail(string vcEmail)
        {
            try
            {
                DataTable userDt = UserDb.GetUserIdByEmail(vcEmail);
                //if (userDt == null) throw new ArgumentNullException(nameof(userDt));
                //var userIdDt = UtilityMethods.ConvertDataTable<usp_GetUserIdByEmail>(userDt);
                //if (userIdDt == null) throw new ArgumentNullException(nameof(userIdDt));
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "UserId Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "UserId Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// InitiateRequest
        /// </summary>
        /// <param name="req"></param>
        /// <param name="fileBytesList"></param>
        /// <returns></returns>
        public OperationResult InitiateRequest(ISMRequestInitiation req, List<byte[]> fileBytesList)
        {
            try
            {
                //string AppendedIssuenumber;
                //string vcVS;
                DataTable res = UserDb.InitiateRequest(req, fileBytesList);
                if (Convert.ToInt32(res.Rows[0]["returnValue"]) == 1)
                {
                    //AppendedIssuenumber = res.Rows[0]["appendedIssueNumber"].ToString();
                    //vcVS = res.Rows[0]["vcVS"].ToString();
                    //using (var impersonation = new ImpersonatedUser(decryptedUser, decryptedDomain, decryptedPassword))
                    //{
                    //    if (!(Directory.Exists(FolderPath + vcVS + AppendedIssuenumber)))
                    //    {
                    //        Directory.CreateDirectory(FolderPath + "\\" + vcVS + "\\" + AppendedIssuenumber);
                    //    }
                    //}
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "File inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "File not Inserted",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// UpdateRequest
        /// </summary>
        /// <param name="req"></param>
        /// <param name="fileBytesList"></param>
        /// <returns></returns>
        public OperationResult UpdateRequest(ISMRequestUpdation req, List<byte[]> fileBytesList)
        {
            try
            {
                int res = UserDb.UpdateRequest(req, fileBytesList);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "File inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "File not Inserted",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetAssignGroup
        /// </summary>
        /// <returns></returns>
        public OperationResult GetAssignGroup(int iVSId)
        {
            try
            {
                DataTable userDt = UserDb.GetAssignGroup(iVSId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Groups existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "There are no groups existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetGroups(int iVSId)
        {
            try
            {
                DataTable userDt = UserDb.GetGroups(iVSId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Groups existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "There are no groups existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetAllUsers(int iVSId)
        {
            try
            {
                DataTable userDt = UserDb.GetAllUsers(iVSId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Users existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "There are no Users existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// GetProductLine
        /// </summary>
        /// <returns></returns>
        public OperationResult GetProductLine(int iCategory)
        {
            try
            {
                DataTable userDt = UserDb.GetProductLine(iCategory);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Product Line existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Product Line existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetPartNumber
        /// </summary>
        /// <returns></returns>
        public OperationResult GetPartNumber(int iProductline, int iCategory)
        {
            try
            {
                DataTable userDt = UserDb.GetPartNumber(iProductline, iCategory);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PartNumber existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No PartNumber existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetCategory
        /// </summary>
        /// <returns></returns>
        public OperationResult GetCategory()
        {
            try
            {
                DataTable userDt = UserDb.GetCategory();
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PartNumber existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No PartNumber existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetUserGroups
        /// </summary>
        /// <param name="iGroupID"></param>
        /// <returns></returns>
        public OperationResult GetUserGroups(int iGroupID, int iVSId)
        {
            try
            {
                DataTable userDt = UserDb.GetUserGroups(iGroupID, iVSId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "UserGroup existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No User Groups existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetPriority
        /// </summary>
        /// <returns></returns>
        public OperationResult GetPriority(int iVSId)
        {
            try
            {
                DataTable userDt = UserDb.GetPriority(iVSId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Priority existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Priority existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetMyQueueDet
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public OperationResult GetMyQueueDet(int iUserId, int iVSId)
        {
            try
            {
                DataTable userDt = UserDb.GetMyQueueDet(iUserId, iVSId);
                if (userDt == null) throw new ArgumentNullException(nameof(userDt));
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "UserId Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "UserId Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetDashboardDet
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public OperationResult GetDashboardDet(int iUserId)
        {
            try
            {
                DataTable userDt = UserDb.GetDashboardDet(iUserId);
                if (userDt == null) throw new ArgumentNullException(nameof(userDt));
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Dashboard Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Dashboard Details Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetDashboardCount
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public OperationResult GetDashboardCount(int iUserId)
        {
            try
            {
                DataTable userDt = UserDb.GetDashboardCount(iUserId);
                if (userDt == null) throw new ArgumentNullException(nameof(userDt));
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Dashboard Count Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Dashboard Count Details Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetIssueDetails
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        public OperationResult GetIssueDetails(int iIssueNumber)
        {
            try
            {
                DataTable IssueDetailsDt = UserDb.GetIssueDetails(iIssueNumber);
                if (IssueDetailsDt == null) throw new ArgumentNullException(nameof(iIssueNumber));
                if (IssueDetailsDt.Rows.Count > 0)
                {
                    if (IssueDetailsDt.Columns.Contains("vcComments"))
                        foreach (DataRow row in IssueDetailsDt.Rows)
                        {
                            row["vcComments"] = StripHTML(row["vcComments"].ToString());
                        }
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Issue Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = IssueDetailsDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Issue Details Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = IssueDetailsDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// DisplayUploadedFiles
        /// </summary>
        /// <param name="iInsId"></param>
        /// <returns></returns>
        public DataTable DisplayUploadedFiles(int iInsId)
        {
            try
            {
                DataTable res = UserDb.DisplayUploadedFiles(iInsId);
                return res;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetBasestring
        /// </summary>
        /// <param name="iDocId"></param>
        /// <returns></returns>
        public DataTable GetBasestring(int iDocId)
        {
            try
            {
                DataTable res = UserDb.GetBasestring(iDocId);
                return res;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetDipositionType
        /// </summary>
        /// <returns></returns>
        public OperationResult GetDipositionType(int iWorkFlowID, int iVSId)
        {
            try
            {
                DataTable userDt = UserDb.GetDipositionType(iWorkFlowID, iVSId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Diposition existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Diposition existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetHistory
        /// </summary>
        /// <param name="iActivityOwner"></param>
        /// <returns></returns>
        public OperationResult GetHistory(int iIssueNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetHistory(iIssueNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "History existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No History existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// GetHistory
        /// </summary>
        /// <param name="iActivityOwner"></param>
        /// <returns></returns>
        public OperationResult GetDispositionHistory(int iIssueWFID)
        {
            try
            {
                DataSet resultDs = UserDb.GetDispositionHistory(iIssueWFID);
                if (resultDs.Tables.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "History existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDs
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No History existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDs
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// GetMyQueueSearch
        /// </summary>
        /// <param name="iUserId"></param>
        /// <param name="iIssueNumber"></param>
        /// <param name="iType"></param>
        /// <returns></returns>
        public OperationResult GetMyQueueSearch(int iUserId, string iIssueNumber, int iType, int? iProductLine, int? iPartNumber, string dStartDate, string dEndDate, int iVSId, string vcQNNumber, string vcOtherPartNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetMyQueueSearch(iUserId, iIssueNumber, iType, iProductLine, iPartNumber, dStartDate, dEndDate, iVSId, vcQNNumber, vcOtherPartNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "History existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No History existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetRolesByUserId
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public OperationResult GetRolesByUserId(int iUserId)
        {
            try
            {
                DataTable resultDt = UserDb.GetRolesByUserId(iUserId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "History existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No History existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// UpdateToSwitchRole
        /// </summary>
        /// <param name="iCurrentRole"></param>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public OperationResult UpdateToSwitchRole(int iCurrentRole, int iUserId)
        {
            try
            {
                int resultValue = UserDb.UpdateToSwitchRole(iCurrentRole, iUserId);
                if (resultValue == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Update Success",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultValue
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Update fail",
                        MCode = MessageCode.OperationFailed,
                        Data = resultValue
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDispositionType(int iIssueWFID)
        {
            try
            {
                DataTable IssueDetailsDt = UserDb.GetDispositionType(iIssueWFID);
                if (IssueDetailsDt == null) throw new ArgumentNullException(nameof(iIssueWFID));
                if (IssueDetailsDt.Rows.Count > 0)
                {
                    if (IssueDetailsDt.Columns.Contains("Comments"))
                        foreach (DataRow row in IssueDetailsDt.Rows)
                        {
                            row["Comments"] = StripHTML(row["Comments"].ToString());
                        }

                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = IssueDetailsDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Disposition Details Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = IssueDetailsDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetAssignedToEmail(int iUserId)
        {
            try
            {
                DataTable IssueDetailsDt = UserDb.GetAssignedToEmail(iUserId);
                if (IssueDetailsDt == null) throw new ArgumentNullException(nameof(iUserId));
                if (IssueDetailsDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Email Id Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = IssueDetailsDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Email Id Details Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = IssueDetailsDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetWorkflowTypes(int iVSid)
        {
            try
            {
                DataTable WorkflowDt = UserDb.GetWorkflowTypes(iVSid);
                if (WorkflowDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Workflow type Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = WorkflowDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Workflow type Details Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = WorkflowDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDashboardTopCount(int iUserId,int? month)
        {
            try
            {
                DataTable IssueDetailsDt = UserDb.GetDashboardTopCount(iUserId, month);
                if (IssueDetailsDt == null) throw new ArgumentNullException(nameof(iUserId));
                if (IssueDetailsDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Dashboard Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = IssueDetailsDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Dashboard Details Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = IssueDetailsDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetWFDId(int iWorkFlowID, int iDispositionID)
        {
            try
            {
                DataTable WFDIdDt = UserDb.GetWFDId(iWorkFlowID, iDispositionID);
                if (WFDIdDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "WFDId Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = WFDIdDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Dashboard Details Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = WFDIdDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult UpdateIssueDisposition_InsertDtransaction(PIUpdateDispositionRecords req, List<byte[]> fileBytesList)
        {
            try
            {
                int res = UserDb.UpdateIssueDisposition_InsertDtransaction(req, fileBytesList);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "File updated inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "File not Inserted and not updated",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult UpdateDispositionWFRequest(PIUpdateDispositionRecords req, List<byte[]> fileBytesList)
        {
            try
            {
                int res = UserDb.UpdateDispositionWFRequest(req, fileBytesList);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "UpdateDispositionWFRequest Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "UpdateDispositionWFRequest not updated",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetHistory
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        public OperationResult GetCCEmails(int iIssueNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetCCEmails(iIssueNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "CCMails existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "CCMails not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        // usp_ISM_GetDispositionCCMailsByIssue(int iIssueNumber)
        /// <summary>
        /// GetHistory
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        public OperationResult GetDispositionCCMailsByIssue(int iDispositionNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetDispositionCCMailsByIssue(iDispositionNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition CCMails existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Disposition CCMails not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetExistingDispositionsByIssueNumber(int iIssueNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetExistingDispositionsByIssueNumber(iIssueNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Disposition details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetWorkflowType(int iIssueNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetWorkflowType(iIssueNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Workflow type existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Workflow type not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetUploadedDocsForDisposition(int iIssueNumber, int iIssueWFID)
        {
            try
            {
                DataTable resultDt = UserDb.GetUploadedDocsForDisposition(iIssueNumber, iIssueWFID);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition docs existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Disposition docs not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //GetIssueNumberByWFID(int iIssueWFID)
        public OperationResult GetIssueNumberByWFID(int iIssueWFID)
        {
            try
            {
                DataTable resultDt = UserDb.GetIssueNumberByWFID(iIssueWFID);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Issue Id existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Issue Id not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //GetWorkflowDetails(int iIssueWFID)
        public OperationResult GetWorkflowDetails(int iIssueWFID)
        {
            try
            {
                DataTable resultDt = UserDb.GetWorkflowDetails(iIssueWFID);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Disposition Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //GetMyQueueDisposition(int iUserId)
        public OperationResult GetMyQueueDisposition(int iUserId)
        {
            try
            {
                DataTable resultDt = UserDb.GetMyQueueDisposition(iUserId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "MyQueueDisposition Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "MyQueueDisposition Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //GetProductLineForPCN
        public OperationResult GetProductLineForPCN(int iVSId)
        {
            try
            {
                DataTable resultDt = UserDb.GetProductLineForPCN(iVSId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PL for PCN Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "PL for PCN Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetPartNumberPCN(int iProductline, int iVSId)
        {
            try
            {
                DataTable resultDt = UserDb.GetPartNumberPCN(iProductline, iVSId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PL for PCN Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "PL for PCN Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetPartDescription(int iPartNumberID)
        {
            try
            {
                DataTable resultDt = UserDb.GetPartDescription(iPartNumberID);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PartDescription Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "PartDescription Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetCategoryNameByPL(int iProductLineID)
        {
            try
            {
                DataTable resultDt = UserDb.GetCategoryNameByPL(iProductLineID);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Category Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetDispositionStatusByIssueNumber(int iIssueNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetDispositionStatusByIssueNumber(iIssueNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Status Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Staus Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetIssueStatusByIssueNumber(int iIssueNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetIssueStatusByIssueNumber(iIssueNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Status Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Staus Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }


        #region--Lov
        #region WorkFlow
        public OperationResult GetLOVWorkFlow()
        {
            try
            {
                DataTable WFDt = UserDb.GetLOVWorkFlow();
                if (WFDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "WorkFlow existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = WFDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No WorkFlow existed",
                        MCode = MessageCode.OperationFailed,
                        Data = WFDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetLOVWorkFlow(int iWorkFlowID)
        {
            try
            {
                DataTable WFDt = UserDb.GetLOVWorkFlow(iWorkFlowID);
                if (WFDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "WorkFlow existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = WFDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No WorkFlow existed",
                        MCode = MessageCode.OperationFailed,
                        Data = WFDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateWorkFlowDet(WFObj req)
        {
            try
            {
                int res = UserDb.UpdateWorkFlowDet(req);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "WorkFlow details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "WorkFlow details updated Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidateWorkFlowDet(WFObj req)
        {
            try
            {
                DataTable WFDt = UserDb.ValidateWorkFlowDet(req);
                if (WFDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "WorkFlow exists",
                        MCode = MessageCode.OperationSuccessful,
                        Data = WFDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No WorkFlow exists",
                        MCode = MessageCode.OperationFailed,
                        Data = WFDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertWorkFlowDet(WFObj req)
        {
            try
            {
                int res = UserDb.InsertWorkFlowDet(req);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Workflow details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Workflow details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Dsiposition

        public OperationResult GetLOVDisposition()
        {
            try
            {
                DataTable DPDt = UserDb.GetLOVDisposition();
                if (DPDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = DPDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Disposition existed",
                        MCode = MessageCode.OperationFailed,
                        Data = DPDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetLOVDisposition(int iDispositionTypeID)
        {
            try
            {
                DataTable WFDt = UserDb.GetLOVDsiposition(iDispositionTypeID);
                if (WFDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Dsiposition existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = WFDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Disposition existed",
                        MCode = MessageCode.OperationFailed,
                        Data = WFDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateDispositionDet(DPObj req)
        {
            try
            {
                int res = UserDb.UpdateDispositionDet(req);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Disposition details updated Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidateDispositionDet(DPObj req)
        {
            try
            {
                DataTable DPDt = UserDb.ValidateDispositionDet(req);
                if (DPDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition exists",
                        MCode = MessageCode.OperationSuccessful,
                        Data = DPDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Disposition exists",
                        MCode = MessageCode.OperationFailed,
                        Data = DPDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertDispositionDet(DPObj req)
        {
            try
            {
                int res = UserDb.InsertDispositionDet(req);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Disposition details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Disposition details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Category

        public OperationResult GetLOVCategory()
        {
            try
            {
                DataTable CDt = UserDb.GetLOVCategory();
                if (CDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = CDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Category existed",
                        MCode = MessageCode.OperationFailed,
                        Data = CDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetLOVCategory(int iCategoryID)
        {
            try
            {
                DataTable CTDt = UserDb.GetLOVCategory(iCategoryID);
                if (CTDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = CTDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Category existed",
                        MCode = MessageCode.OperationFailed,
                        Data = CTDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetLOVALLCategory()
        {
            try
            {
                DataTable CTDt = UserDb.GetLOVALLCategory();
                if (CTDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = CTDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Category existed",
                        MCode = MessageCode.OperationFailed,
                        Data = CTDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult UpdateCategoryDet(CObj creq)
        {
            try
            {
                int res = UserDb.UpdateCategoryDet(creq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Category details updated Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidateCategoryDet(CObj creq)
        {
            try
            {
                DataTable CTDt = UserDb.ValidateCategoryDet(creq);
                if (CTDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category exists",
                        MCode = MessageCode.OperationSuccessful,
                        Data = CTDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Category exists",
                        MCode = MessageCode.OperationFailed,
                        Data = CTDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertCategoryDet(CObj creq)
        {
            try
            {
                int res = UserDb.InsertCategoryDet(creq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Category details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Product

        public OperationResult GetLOVProductSample(int iVSId)
        {
            try
            {
                DataTable PDt = UserDb.GetLOVProductSample(iVSId);
                if (PDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Product existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Product existed",
                        MCode = MessageCode.OperationFailed,
                        Data = PDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetLOVProduct(int iProductLineID)
        {
            try
            {
                DataTable PRDDt = UserDb.GetLOVProduct(iProductLineID);
                if (PRDDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Product existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PRDDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Product existed",
                        MCode = MessageCode.OperationFailed,
                        Data = PRDDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateProductDet(PRDObj preq)
        {
            try
            {
                int res = UserDb.UpdateProductDet(preq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Product details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Product details updated Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidateProductDet(PRDObj preq)
        {
            try
            {
                DataTable PRDDt = UserDb.ValidateProductDet(preq);
                if (PRDDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Product exists",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PRDDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Product exists",
                        MCode = MessageCode.OperationFailed,
                        Data = PRDDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertProductDet(PRDObj preq)
        {
            try
            {
                int res = UserDb.InsertProductDet(preq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Product details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Product details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Priority

        public OperationResult GetLOVPrioritySample(int iVSId)
        {
            try
            {
                DataTable PRDt = UserDb.GetLOVPrioritySample(iVSId);
                if (PRDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Priority existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PRDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Priority existed",
                        MCode = MessageCode.OperationFailed,
                        Data = PRDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetLOVPriority(int iPriorityID)
        {
            try
            {
                DataTable PRTDt = UserDb.GetLOVPriority(iPriorityID);
                if (PRTDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Priority existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PRTDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Priority existed",
                        MCode = MessageCode.OperationFailed,
                        Data = PRTDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdatePriorityDet(PRIObj preq)
        {
            try
            {
                int res = UserDb.UpdatePriorityDet(preq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Priority details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Priority details updated Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidatePriorityDet(PRIObj preq)
        {
            try
            {
                DataTable PRTDt = UserDb.ValidatePriorityDet(preq);
                if (PRTDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Priority exists",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PRTDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Priority exists",
                        MCode = MessageCode.OperationFailed,
                        Data = PRTDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertPriorityDet(PRIObj preq)
        {
            try
            {
                int res = UserDb.InsertPriorityDet(preq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Priority details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Priority details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region PartNumber

        public OperationResult GetLOVPartNumberSample(int iVSId)
        {
            try
            {
                DataTable PNDt = UserDb.GetLOVPartNumberSample(iVSId);
                if (PNDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PartNumber existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PNDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No PartNumber existed",
                        MCode = MessageCode.OperationFailed,
                        Data = PNDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetLOVPartNumber(int iPartNumberID)
        {
            try
            {
                DataTable PNDt = UserDb.GetLOVPartNumber(iPartNumberID);
                if (PNDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PartNumber existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PNDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No PartNumber existed",
                        MCode = MessageCode.OperationFailed,
                        Data = PNDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdatePartNumberDet(PNObj preq)
        {
            try
            {
                int res = UserDb.UpdatePartNumberDet(preq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PartNumber details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "PartNumber details updated Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidatePartNumberDet(PNObj pnreq)
        {
            try
            {
                DataTable PNDt = UserDb.ValidatePartNumberDet(pnreq);
                if (PNDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PartNumber exists",
                        MCode = MessageCode.OperationSuccessful,
                        Data = PNDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No PartNumber exists",
                        MCode = MessageCode.OperationFailed,
                        Data = PNDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertPartNumberDet(PNObj preq)
        {
            try
            {
                int res = UserDb.InsertPartNumberDet(preq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "PartNumber details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "PartNumber details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Status

        public OperationResult GetLOVStatus()
        {
            try
            {
                DataTable SDt = UserDb.GetLOVStatus();
                if (SDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Status existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = SDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Status existed",
                        MCode = MessageCode.OperationFailed,
                        Data = SDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetLOVStatus(int iStatusID)
        {
            try
            {
                DataTable SDt = UserDb.GetLOVStatus(iStatusID);
                if (SDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Status existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = SDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Status existed",
                        MCode = MessageCode.OperationFailed,
                        Data = SDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateStatusDet(SObj sreq)
        {
            try
            {
                int res = UserDb.UpdateStatusDet(sreq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Status details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Status details updated Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidateStatusDet(SObj sreq)
        {
            try
            {
                DataTable SDt = UserDb.ValidateStatusDet(sreq);
                if (SDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Status exists",
                        MCode = MessageCode.OperationSuccessful,
                        Data = SDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Status exists",
                        MCode = MessageCode.OperationFailed,
                        Data = SDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertStatusDet(SObj sreq)
        {
            try
            {
                int res = UserDb.InsertStatusDet(sreq);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Status details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Status details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region Group
        public OperationResult InsertGroups(GroupObj req)
        {
            try
            {
                int res = UserDb.InsertGroups(req);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Group details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else if (res == 2)
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Group details already existed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Group details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetLOVGroup(int iVSId)
        {
            try
            {
                DataTable GDt = UserDb.GetLOVGroup(iVSId);
                if (GDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Goup existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = GDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Group not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = GDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateGroupEdit(int iGroupID, string vcGroupDescription, int bStatus)
        {
            try
            {
                int res = UserDb.UpdateGroupEdit(iGroupID, vcGroupDescription, bStatus);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Group details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Group details updated Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetGroupRecordByGroupId(int iGroupID)
        {
            try
            {
                DataTable GDt = UserDb.GetGroupRecordByGroupId(iGroupID);
                if (GDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Goup existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = GDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Group not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = GDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult CheckCurrentGroupStatus(int iAssignedGroupTo)
        {
            try
            {
                int res = UserDb.CheckCurrentGroupStatus(iAssignedGroupTo);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Group details updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "This group is assigned to some Issue or Disposition",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region
        public OperationResult GetUserGroups()
        {
            try
            {
                DataTable userDt = UserDb.GetUserGroups();
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Group existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Group existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetUserGroupById(int iUserGroupID)
        {
            try
            {
                DataTable userDt = UserDb.GetUserGroupById(iUserGroupID);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Group existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Group existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertUserGroup(int iUserID, int iGroupID, int iStatus, int iCreatedBy, int iVSId)
        {
            try
            {
                int res = UserDb.InsertUserGroup(iUserID, iGroupID, iStatus, iCreatedBy, iVSId);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User Group details inserted Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else if (res == 2)
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Group details already existed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Group details insertion Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //UpdateUserGroup(int iUserGroupID, int iUserID, int iGroupID,int iStatus)
        public OperationResult UpdateUserGroup(int iUserGroupID, int iUserID, int iStatus, int iUpdatedBy, int iGroupID, int isAdmin)
        {
            try
            {
                int res = UserDb.UpdateUserGroup(iUserGroupID, iUserID, iStatus, iUpdatedBy, iGroupID, isAdmin);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User Group details Updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Group details Updation Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region UserAccess
        public OperationResult GetRequestedUsers(int iVSId)
        {
            try
            {
                DataTable userDt = UserDb.GetRequestedUsers(iVSId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Users existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Users existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateUsersAccess(int iUserId, int iUpdatedBy, int iGroupId, int isAdmin, int iVSId,int iRejectStatus)
        {
            try
            {
                int res = UserDb.UpdateUsersAccess(iUserId, iUpdatedBy, iGroupId, isAdmin, iVSId, iRejectStatus);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User access updated Successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else if (res == 2)
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User access updation Failed",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetSelectedRequestUser(int iUserId)
        {
            try
            {
                DataTable userDt = UserDb.GetSelectedRequestUser(iUserId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Users existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Users existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetGivenNameByEmailId(string emailId)
        {
            try
            {
                DataTable userDt = UserDb.GetGivenNameByEmailId(emailId);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Email existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Email not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region Email

        public OperationResult EmailConfiguration(EmailAttributes req)
        {
            try
            {
                string RegisteredUserEmail = req.toAddress;//req.toAddress//req.toCC--Both were registered emails
                var emailhelper = new EmailNotification();
                string AdminEmails = string.Empty;
                if (req.AdminCCEmails.Length > 0)
                    AdminEmails = string.Join(",", req.AdminCCEmails);
                else
                    AdminEmails = "";

                StringBuilder sb = new StringBuilder();
                if (req.centerMessage != null)
                {
                    sb.Append("<h2><center>" + req.centerMessage + "</center></h2>");
                    //sb.Append("<br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                }
                if (req.body != null)
                    sb.Append("<p>" + req.body + "</p>");

                sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                //emailhelper.SendMailToAdmin(req.toAddress, ccMails, ccMails, req.subject, sb.ToString(), true);
                //emailhelper.SendMailToAdmin(req.toAddress, ccMails, "", req.subject, sb.ToString(), true);
                emailhelper.SendMailToAdmin(AdminEmails, AdminEmails, "", req.subject, sb.ToString(), true);
                StringBuilder sbAdmin = new StringBuilder();
                sbAdmin.Append("<p>Hello Admin</p> ");
                sbAdmin.Append("<br />Please click the link to open the ISM Dashboard Tool :<a href='" + ManageUserAccess + "'>click here</a>");
                if (req.body != null)
                    sbAdmin.Append("<p>" + req.body + "</p>");
                sbAdmin.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                emailhelper.SendMailToAdmin("", AdminEmails, "", req.subject, sbAdmin.ToString(), true);
                //emailhelper.SendMailToAdmin(AdminEmails, AdminEmails, "", req.subject, sbAdmin.ToString(), true);

                return new OperationResult()
                {
                    Success = true,
                    Message = "Email Sent Successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 1
                };
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return new OperationResult()
                {
                    Success = false,
                    Message = "Email not sent",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 0
                };
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return new OperationResult()
                {
                    Success = false,
                    Message = "Email not sent",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 0
                };
            }
        }

        public OperationResult EmailConfigurationToApprovedUsers(EmailAttributes req)
        {
            try
            {
                var emailhelper = new EmailNotification();
                string toreply = string.Empty;
                StringBuilder sb = new StringBuilder();
                if (req.centerMessage != null)
                    sb.Append("<h2><center>" + req.centerMessage + "</center></h2>");
                sb.Append("<p>Hi " + req.requetor + ",</p> ");
                if (req.body != null)
                    sb.Append("<p>" + req.body + "</p>");
                sb.Append("<br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                emailhelper.SendMailToAdmin(req.toAddress, req.toAddress, "", req.subject, sb.ToString(), true);

                return new OperationResult()
                {
                    Success = true,
                    Message = "Email Sent Successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 1
                };
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return new OperationResult()
                {
                    Success = false,
                    Message = "Email not sent",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 0
                };
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return new OperationResult()
                {
                    Success = false,
                    Message = "Email not sent",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 0
                };
            }
        }

        public OperationResult EmailConfigurationToRejectedUsers(EmailAttributes req)
        {
            try
            {
                var emailhelper = new EmailNotification();
                string toreply = string.Empty;
                StringBuilder sb = new StringBuilder();
                if (req.centerMessage != null)
                    sb.Append("<h2><center>" + req.centerMessage + "</center></h2>");
                sb.Append("<p>Hi " + req.requetor + ",</p> ");
                if (req.body != null)
                    sb.Append("<p>"+req.body+"</p>");
                //sb.Append("<br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                emailhelper.SendMailToAdmin(req.toAddress, req.toAddress, "", req.subject, sb.ToString(), true);

                return new OperationResult()
                {
                    Success = true,
                    Message = "Email Sent Successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 1
                };
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return new OperationResult()
                {
                    Success = false,
                    Message = "Email not sent",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 0
                };
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return new OperationResult()
                {
                    Success = false,
                    Message = "Email not sent",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 0
                };
            }
        }

        #endregion

        #region--GetGroups
        public OperationResult GetGroupWithNoOfUsers(int iVSId)
        {
            try
            {
                DataTable GDt = UserDb.GetGroupWithNoOfUsers(iVSId);
                if (GDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Goup existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = GDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Group not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = GDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //GetGroupUsers(int iGroupID)
        public OperationResult GetGroupUsers(int iGroupID)
        {
            try
            {
                DataTable GDt = UserDb.GetGroupUsers(iGroupID);
                if (GDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Goup existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = GDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Group not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = GDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion
        public OperationResult GetRegistration_CCMails(int iSBUVS)
        {
            try
            {
                DataTable AdminEmailDt = UserDb.GetRegistration_CCMails(iSBUVS);
                if (AdminEmailDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Admin Emails existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = AdminEmailDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Admin Emails existed",
                        MCode = MessageCode.OperationFailed,
                        Data = AdminEmailDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDashboardAgingIssues(int iUserId)
        {
            try
            {
                DataTable DashboardAgingIssuesDt = UserDb.GetDashboardAgingIssues(iUserId);
                if (DashboardAgingIssuesDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Admin Emails existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = DashboardAgingIssuesDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Admin Emails existed",
                        MCode = MessageCode.OperationFailed,
                        Data = DashboardAgingIssuesDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDashboardStackChart(int iUserId)
        {
            try
            {
                DataTable GetDashboardStackChartDt = UserDb.GetDashboardStackChart(iUserId);
                if (GetDashboardStackChartDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Items existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = GetDashboardStackChartDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No items existed",
                        MCode = MessageCode.OperationFailed,
                        Data = GetDashboardStackChartDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDashboardFunctionWiseChart(int iUserId)
        {
            try
            {
                DataTable GetDashboardStackChartDt = UserDb.GetDashboardFunctionWiseChart(iUserId);
                if (GetDashboardStackChartDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Items existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = GetDashboardStackChartDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No items existed",
                        MCode = MessageCode.OperationFailed,
                        Data = GetDashboardStackChartDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetDashboardDonutChart(int iUserId)
        {
            try
            {
                DataTable GetDashboardStackChartDt = UserDb.GetDashboardDonutChart(iUserId);
                if (GetDashboardStackChartDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Items existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = GetDashboardStackChartDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No items existed",
                        MCode = MessageCode.OperationFailed,
                        Data = GetDashboardStackChartDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetAgedTicketsByCategory(int icategory, int iVSId)
        {
            try
            {
                DataTable Dt = UserDb.GetAgedTicketsByCategory(icategory, iVSId);
                if (Dt.Rows.Count > 0)
                {
                    if (Dt.Columns.Contains("vcIssueDescription"))
                        foreach (DataRow row in Dt.Rows)
                        {
                            row["vcIssueDescription"] = StripHTML(row["vcIssueDescription"].ToString());
                        }
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Items existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = Dt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No items existed",
                        MCode = MessageCode.OperationFailed,
                        Data = Dt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDashboardStackChartByProduct(string productlist)
        {
            try
            {
                DataTable Dt = UserDb.GetDashboardStackChartByProduct(productlist);
                if (Dt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Items existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = Dt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No items existed",
                        MCode = MessageCode.OperationFailed,
                        Data = Dt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        //DataTable GetAllPartNumber()
        public OperationResult GetAllPartNumber()
        {
            try
            {
                DataTable resultDt = UserDb.GetAllPartNumber();
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Part number Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Part number Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //GetDashboardStackChartByProductDate(string productlist, string startdate, string enddate)
        public OperationResult GetDashboardStackChartByProductDate(string productlist, string startdate, string enddate)
        {
            try
            {
                DataTable resultDt = UserDb.GetDashboardStackChartByProductDate(productlist, startdate, enddate);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //GetDashboardStackChartBypartNumber(string partidList, string startdate, string enddate)
        public OperationResult GetDashboardStackChartBypartNumber(string partidList, string startdate, string enddate)
        {
            try
            {
                DataTable resultDt = UserDb.GetDashboardStackChartBypartNumber(partidList, startdate, enddate);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //GetPartnumberBasedOnMultipleProductLines(string iProductLineID)
        public OperationResult GetPartnumberBasedOnMultipleProductLines(string iProductLineID, int iVSid)
        {
            try
            {
                DataTable resultDt = UserDb.GetPartnumberBasedOnMultipleProductLines(iProductLineID, iVSid);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDashboardMultipLineChart(Linegraphproperties req)
        {
            try
            {
                DataTable resultDt = UserDb.GetDashboardMultipLineChart(req);

                if (resultDt != null && resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetDashboardMultipLineChartExport(Linegraphproperties req)
        {
            try
            {
                DataTable resultDt = UserDb.GetDashboardMultipLineChartExport(req);

                if (resultDt != null && resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult TestGraph()
        {
            try
            {
                //DataTable resultDt = UserDb.TestGraph();
                DataTable resultDt = Transpose(UserDb.TestGraph());
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetAllDispositions()
        {
            try
            {
                DataTable resultDt = UserDb.GetAllDispositions();
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ManageWorkflowDispositions(int iVSid)
        {
            try
            {
                DataTable resultDt = UserDb.ManageWorkflowDispositions(iVSid);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetWorkflowDispositions(int iWorkFlowID, int iVSId)
        {
            try
            {
                DataTable resultDt = UserDb.GetWorkflowDispositions(iWorkFlowID, iVSId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //InsertWorkflowDisposition(int iWorkFlowID, string vcDispositionName, int iCreatedBy, string vcDPAlias)
        public OperationResult InsertWorkflowDisposition(int iWorkFlowID, string vcDispositionName, int iCreatedBy, string vcDPAlias)
        {
            try
            {
                int res = UserDb.InsertWorkflowDisposition(iWorkFlowID, vcDispositionName, iCreatedBy, vcDPAlias);
                if (res == 1)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details inserted successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = res
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details insertion fail",
                        MCode = MessageCode.OperationFailed,
                        Data = res
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        private DataTable Transpose(DataTable dt)
        {
            //DataTable dt2 = new DataTable();
            //for (int i = 0; i <= dt.Rows.Count; i++)
            //{
            //    dt2.Columns.Add();
            //}
            //for (int i = 0; i < dt.Columns.Count; i++)
            //{
            //    dt2.Rows.Add();
            //    dt2.Rows[i][0] = dt.Columns[i].ColumnName;
            //}
            //for (int i = 0; i < dt.Columns.Count; i++)
            //{
            //    for (int j = 0; j < dt.Rows.Count; j++)
            //    {
            //        dt2.Rows[i][j + 1] = dt.Rows[j][i];
            //    }
            //}
            ////dt2.Rows[0].Delete();
            ////dt2.AcceptChanges();
            //return dt2;

            DataTable outputTable = new DataTable();

            // Add columns by looping rows

            // Header row's first column is same as in inputTable
            outputTable.Columns.Add(dt.Columns[0].ColumnName.ToString());

            // Header row's second column onwards, 'inputTable's first column taken
            foreach (DataRow inRow in dt.Rows)
            {
                string newColName = inRow[0].ToString();
                outputTable.Columns.Add(newColName);
            }

            // Add rows by looping columns        
            for (int rCount = 1; rCount <= dt.Columns.Count - 1; rCount++)
            {
                DataRow newRow = outputTable.NewRow();

                // First column is inputTable's Header row's second column
                newRow[0] = dt.Columns[rCount].ColumnName.ToString();
                for (int cCount = 0; cCount <= dt.Rows.Count - 1; cCount++)
                {
                    string colValue = dt.Rows[cCount][rCount].ToString();
                    newRow[cCount + 1] = colValue;
                }
                outputTable.Rows.Add(newRow);
            }
            return outputTable;
        }

        public OperationResult EmailFeedback(EmailAttributes req)
        {
            try
            {
                string ccMails = req.toAddress;
                var emailhelper = new EmailNotification();
                //string toreply = string.Empty;
                //if (req.AdminCCEmails.Length > 0)
                //    toreply = string.Join(",", req.AdminCCEmails);
                //else
                //    toreply = "";

                StringBuilder sb = new StringBuilder();
                if (req.centerMessage != null)
                {
                    sb.Append("<h2><center>" + req.centerMessage + "</center></h2>");

                }
                //if (req.body != null)
                //    sb.Append("<p>" + req.body + "</p>");
                // sb.Append("<br />"+req.text);
                sb.Append("<br />Thanks for sharing your valuable feedback with us.");
                sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                emailhelper.SendMailToAdmin(req.toCC, req.toCC, ccMails, req.subject, sb.ToString(), true);


                StringBuilder sbAdmin = new StringBuilder();
                sbAdmin.Append("<p>Hello Admin</p> ");
                //sbAdmin.Append("<br />Please click the link to open the ISM Dashboard Tool :<a href='" + ManageUserAccess + "'>click here</a>");
                if (req.body != null)
                    sbAdmin.Append("<p>" + req.body + "</p>");
                sbAdmin.Append("<p>" + req.text + "</p>");
                sbAdmin.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                emailhelper.SendMailToAdmin(req.toAddress, req.toAddress, ccMails, req.subject, sbAdmin.ToString(), true);

                return new OperationResult()
                {
                    Success = true,
                    Message = "Email Sent Successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 1
                };
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return new OperationResult()
                {
                    Success = false,
                    Message = "Email not sent",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 0
                };
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return new OperationResult()
                {
                    Success = false,
                    Message = "Email not sent",
                    MCode = MessageCode.OperationSuccessful,
                    Data = 0
                };
            }
        }

        public OperationResult GetEmailsForInitiator_LastprocessedUser(int iIssueNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetEmailsForInitiator_LastprocessedUser(iIssueNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDashboardTopCount_details(int iUserId, int icategory, int month)
        {
            try
            {
                DataTable resultDt = UserDb.GetDashboardTopCount_details(iUserId, icategory,month);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //Evacs enhancements

        public OperationResult GetSBU()
        {
            try
            {
                DataTable resultDt = UserDb.GetSBU();
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //GetValueStreams(int iSBUId)
        public OperationResult GetValueStreams(int iSBUId)
        {
            try
            {
                DataTable resultDt = UserDb.GetValueStreams(iSBUId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //GroupsBasedOnVS(int iVSId)
        public OperationResult GroupsBasedOnVS(int iVSId)
        {
            try
            {
                DataTable resultDt = UserDb.GroupsBasedOnVS(iVSId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetDispositionDescription(int iIssueWFID)
        {
            try
            {
                DataTable resultDt = UserDb.GetDispositionDescription(iIssueWFID);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetCRCODeatails(int iIssueNumber)
        {
            try
            {
                DataTable resultDt = UserDb.GetCRCODeatails(iIssueNumber);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetCategoriesBasedVS(int iVSId)
        {
            try
            {
                DataTable resultDt = UserDb.GetCategoriesBasedVS(iVSId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public static string StripHTML(string input)
        {
            //Regex regex = new Regex("\\<[^\\>]*\\>");
            Regex regex = new Regex("\\<[^\\>]*\\>|&nbsp;");
            input = regex.Replace(input, String.Empty);

            //--input = Regex.Replace(input, "<[a-zA-Z/].*?>", String.Empty);
            //input = Regex.Replace(input, "<.*?>", String.Empty);            
            //input = Regex.Replace(input, @"<[^>]+>|&nbsp;", "").Trim();
            return input;
        }

        public OperationResult GetCategorById(int iWorkFlowID)
        {
            try
            {
                DataTable resultDt = UserDb.GetCategorById(iWorkFlowID);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        
        public OperationResult IssuesBasedOnValueStream(int iVSId)
        {
            try
            {
                DataTable resultDt = UserDb.IssuesBasedOnValueStream(iVSId);
                if (resultDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Details existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = resultDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Details not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = resultDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //UpdateCategorByWorkFlowID(int iWorkFlowID, string vcWorkFlowName, int iCreatedBy)
        public OperationResult UpdateCategorByWorkFlowID(WFObj req)
        {
            if (req == null) throw new ArgumentNullException(nameof(req));
            try
            {
                var registrationUser = UserDb != null && UserDb.UpdateCategorByWorkFlowID(req);

                if (registrationUser == true)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Updated successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = true
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Update fail",
                        MCode = MessageCode.OperationFailed,
                        Data = false
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult CheckWFExistance(WFObj req)
        {
            if (req == null) throw new ArgumentNullException(nameof(req));
            try
            {
                var registrationUser = UserDb != null && UserDb.CheckWFExistance(req);

                if (registrationUser == true)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Record existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = true
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Record not existed",
                        MCode = MessageCode.OperationFailed,
                        Data = false
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //InsertCategories(WFObj ctreq)
        public OperationResult InsertCategories(WFObj req)
        {
            if (req == null) throw new ArgumentNullException(nameof(req));
            try
            {
                var registrationUser = UserDb != null && UserDb.InsertCategories(req);

                if (registrationUser == true)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category saved successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = true
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Category not saved",
                        MCode = MessageCode.OperationFailed,
                        Data = false
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //Mathu
        public OperationResult GetLOVALLValueStream()//Mathu
        {
            try
            {
                DataTable CTDt = UserDb.GetLOVALLValueStream();
                if (CTDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = CTDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Category existed",
                        MCode = MessageCode.OperationFailed,
                        Data = CTDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetLOVALLSBU()
        {
            try
            {
                DataTable CTDt = UserDb.GetLOVALLSBU();
                if (CTDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Category existed",
                        MCode = MessageCode.OperationSuccessful,
                        Data = CTDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "No Category existed",
                        MCode = MessageCode.OperationFailed,
                        Data = CTDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public class ImpersonatedUser : IDisposable
        {
            IntPtr userHandle;

            WindowsImpersonationContext impersonationContext;

            public ImpersonatedUser(string user, string domain, string password)
            {
                userHandle = IntPtr.Zero;

                bool loggedOn = LogonUser(
                    user,
                    domain,
                    password,
                    LogonType.Interactive,
                    LogonProvider.Default,
                    out userHandle);

                if (!loggedOn)
                    throw new Win32Exception(Marshal.GetLastWin32Error());

                // Begin impersonating the user
                impersonationContext = WindowsIdentity.Impersonate(userHandle);
            }

            public void Dispose()
            {
                if (userHandle != IntPtr.Zero)
                {
                    CloseHandle(userHandle);

                    userHandle = IntPtr.Zero;

                    impersonationContext.Undo();
                }
            }

            [DllImport("advapi32.dll", SetLastError = true)]
            static extern bool LogonUser(

                string lpszUsername,

                string lpszDomain,

                string lpszPassword,

                LogonType dwLogonType,

                LogonProvider dwLogonProvider,

                out IntPtr phToken

                );

            [DllImport("kernel32.dll", SetLastError = true)]
            static extern bool CloseHandle(IntPtr hHandle);

            enum LogonType : int
            {
                Interactive = 2,
                Network = 3,
                Batch = 4,
                Service = 5,
                NetworkCleartext = 8,
                NewCredentials = 9,
            }

            enum LogonProvider : int
            {
                Default = 0,
            }

        }
    }
}
