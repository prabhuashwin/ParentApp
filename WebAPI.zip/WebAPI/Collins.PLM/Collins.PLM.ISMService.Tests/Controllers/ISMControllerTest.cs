﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System.Web.Http;
using Collins.PLM.ISMService.Controllers;
using System.Web.Http.Results;

namespace Collins.PLM.ISMService.Tests.Controllers
{
    [TestClass]
    public class ISMControllerTest
    {
        [TestMethod]
        public void TestGetGroups(int iVSId)
        {
            //Arrange
            //var ExpectedResult = new { userName = userName, emailId = emailId };
            string ExpectedResult = "{ \"Success\": true, \"MCode\": 1, \"Message\": \"Groups existed\", \"Data\": [ { \"iGroupID\": 2, \"vcGroupDescription\": \"Quality Assurance Group\" }, { \"iGroupID\": 3, \"vcGroupDescription\": \"Mechanical Engineering\" }, { \"iGroupID\": 4, \"vcGroupDescription\": \"Power & Controls\" }, { \"iGroupID\": 5, \"vcGroupDescription\": \"Admin Group\" }, { \"iGroupID\": 9, \"vcGroupDescription\": \"ME & TE\" }, { \"iGroupID\": 10, \"vcGroupDescription\": \"ISM\" }, { \"iGroupID\": 11, \"vcGroupDescription\": \"ISM PM\" }, { \"iGroupID\": 12, \"vcGroupDescription\": \"Ops PM\" }, { \"iGroupID\": 13, \"vcGroupDescription\": \"Production\" }, { \"iGroupID\": 14, \"vcGroupDescription\": \"Ops Quality\" }, { \"iGroupID\": 15, \"vcGroupDescription\": \"Supplier Quality\" }, { \"iGroupID\": 16, \"vcGroupDescription\": \"SCM\" }, { \"iGroupID\": 17, \"vcGroupDescription\": \"SME\" }, { \"iGroupID\": 18, \"vcGroupDescription\": \"Component Eng. Team\" }, { \"iGroupID\": 19, \"vcGroupDescription\": \"Test Engineering\" }, { \"iGroupID\": 20, \"vcGroupDescription\": \"Dev group1\" }, { \"iGroupID\": 21, \"vcGroupDescription\": \"Dev group2\" } ] }\"Success\": true, \"MCode\": 1, \"Message\": \"Groups existed\", \"Data\": [ { \"iGroupID\": 2, \"vcGroupDescription\": \"Quality Assurance Group\" }, { \"iGroupID\": 3, \"vcGroupDescription\": \"Mechanical Engineering\" }, { \"iGroupID\": 4, \"vcGroupDescription\": \"Power & Controls\" }, { \"iGroupID\": 5, \"vcGroupDescription\": \"Admin Group\" }, { \"iGroupID\": 9, \"vcGroupDescription\": \"ME & TE\" }, { \"iGroupID\": 10, \"vcGroupDescription\": \"ISM\" }, { \"iGroupID\": 11, \"vcGroupDescription\": \"ISM PM\" }, { \"iGroupID\": 12, \"vcGroupDescription\": \"Ops PM\" }, { \"iGroupID\": 13, \"vcGroupDescription\": \"Production\" }, { \"iGroupID\": 14, \"vcGroupDescription\": \"Ops Quality\" }, { \"iGroupID\": 15, \"vcGroupDescription\": \"Supplier Quality\" }, { \"iGroupID\": 16, \"vcGroupDescription\": \"SCM\" }, { \"iGroupID\": 17, \"vcGroupDescription\": \"SME\" }, { \"iGroupID\": 18, \"vcGroupDescription\": \"Component Eng. Team\" }, { \"iGroupID\": 19, \"vcGroupDescription\": \"Test Engineering\" }, { \"iGroupID\": 20, \"vcGroupDescription\": \"Dev group1\" }, { \"iGroupID\": 21, \"vcGroupDescription\": \"Dev group2\" } ] }";
            var expectedOutput = JsonConvert.SerializeObject(ExpectedResult);
            //Act
            var ISMController = new ISMController();
            IHttpActionResult result = ISMController.GetGroups(iVSId);
            var resultSearch = result as OkNegotiatedContentResult<string>;
            //var serializeResult = JsonConvert.SerializeObject(resultSearch.Content);         

            //Assert            
            Assert.AreEqual(resultSearch.Content, expectedOutput);
            Assert.IsNotNull(resultSearch.Content);
        }
    }
}
