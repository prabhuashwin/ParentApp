﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    RequestController
* File Desc   :    This file contains code pertaining to deal with Application Request.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 25-NOv-2021         Venkataramana         Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using ISM.Business;
using ISM.Business.Dto;
using Collins.PLM.ISM.DataModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Web.Http;
using Collins.PLM.ISM.Business.Dto;

namespace Collins.PLM.ISMService.Controllers
{
    public class ISMController : ApiController
    {
        /// <summary>
        /// InitiateRequest
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost, Route("api/ISM/InitiateRequest")]
        public IHttpActionResult InitiateRequest(ISMRequestInitiation req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                List<byte[]> fileBytesList = new List<byte[]>();
                for (int i = 0; i < req.vbDocument.Count(); i++)
                {
                    byte[] fileBytes = Convert.FromBase64String(req.vbDocument[i].ToString());
                    fileBytesList.Add(fileBytes);
                }
                var operationResult = new UserManager().InitiateRequest(req, fileBytesList);
                return Ok(operationResult);
                //return Ok();
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// UpdateRequest
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost, Route("api/ISM/UpdateRequest")]
        public IHttpActionResult UpdateRequest(ISMRequestUpdation req)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                List<byte[]> fileBytesList = new List<byte[]>();
                for (int i = 0; i < req.vbDocument.Count(); i++)
                {
                    byte[] fileBytes = Convert.FromBase64String(req.vbDocument[i].ToString());
                    fileBytesList.Add(fileBytes);
                }
                var operationResult = new UserManager().UpdateRequest(req, fileBytesList);
                return Ok(operationResult);
                //return Ok();
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        /// <summary>
        /// GetAssignGroup
        /// </summary>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetAssignGroup")]
        public IHttpActionResult GetAssignGroup(int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetAssignGroup(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetGroups")]
        public IHttpActionResult GetGroups(int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetGroups(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetAllUsers")]
        public IHttpActionResult GetAllUsers(int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetAllUsers(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        /// <summary>
        /// GetProductLine
        /// </summary>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetProductLine")]
        public IHttpActionResult GetProductLine(int iCategory)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetProductLine(iCategory);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetPartNumber
        /// </summary>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetPartNumber")]
        public IHttpActionResult GetPartNumber(int iProductline, int iCategory)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetPartNumber(iProductline, iCategory);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetCategory
        /// </summary>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetCategory")]
        public IHttpActionResult GetCategory()
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetCategory();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetUserGroups
        /// </summary>
        /// <param name="iGroupID"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetUserGroups")]
        public IHttpActionResult GetUserGroups(int iGroupID, int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetUserGroups(iGroupID,iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetPriority
        /// </summary>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetPriority")]
        public IHttpActionResult GetPriority(int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetPriority(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetIssueDetails
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetIssueDetails")]
        public IHttpActionResult GetIssueDetails(int iIssueNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetIssueDetails(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// DisplayUploadedFiles
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/DisplayUploadedFiles")]
        public IHttpActionResult DisplayUploadedFiles(int iIssueNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                DataTable operationResultDt = new UserManager().DisplayUploadedFiles(iIssueNumber);

                OperationResult operationResult = new OperationResult();
                if (operationResultDt.Rows.Count > 0)
                {
                    operationResult.Success = true;
                    operationResult.Message = "Groups existed";
                    operationResult.MCode = MessageCode.OperationSuccessful;
                    operationResult.Data = operationResultDt;
                }
                else
                {
                    operationResult.Success = false;
                    operationResult.Message = "There are no groups existed";
                    operationResult.MCode = MessageCode.OperationFailed;
                    operationResult.Data = operationResultDt;
                }
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetBasestring
        /// </summary>
        /// <param name="iDocId"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetBasestring")]
        public IHttpActionResult GetBasestring(int iDocId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                DataTable operationResult = new UserManager().GetBasestring(iDocId);
                byte[] doc = (byte[])(operationResult.Rows[0]["vbDocument"]);
                DocResponse dr = new DocResponse();
                dr.vbDocument = Convert.ToBase64String(doc);
                dr.vcFileName = operationResult.Rows[0]["vcFileName"].ToString();
                return Ok(dr);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetDipositionType
        /// </summary>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetDipositionType")]
        public IHttpActionResult GetDipositionType(int iWorkFlowID, int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetDipositionType(iWorkFlowID, iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetHistory
        /// </summary>
        /// <param name="iActivityOwner"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetHistory")]
        public IHttpActionResult GetHistory(int iIssueNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetHistory(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetDispositionHistory")]
        public IHttpActionResult GetDispositionHistory(int iIssueWFID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetDispositionHistory(iIssueWFID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        /// <summary>
        /// GetHistory
        /// </summary>
        /// <param name="iActivityOwner"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetMyQueueSearch")]
        public IHttpActionResult GetMyQueueSearch(int iUserId, string iIssueNumber, int iType, int? iProductLine, int? iPartNumber, string dStartDate, string dEndDate,int iVSId, string vcQNNumber, string vcOtherPartNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetMyQueueSearch(iUserId, iIssueNumber, iType, iProductLine, iPartNumber, dStartDate, dEndDate, iVSId, vcQNNumber, vcOtherPartNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetDispositionType")]
        public IHttpActionResult GetDispositionType(int iIssueWFID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetDispositionType(iIssueWFID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetAssignedToEmail")]
        public IHttpActionResult GetAssignedToEmail(int iUserId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetAssignedToEmail(iUserId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        [HttpGet, Route("api/ISM/GetWorkflowTypes")]
        public IHttpActionResult GetWorkflowTypes(int iVSid)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetWorkflowTypes(iVSid);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetDashboardTopCount")]
        public IHttpActionResult GetDashboardTopCount(int iUserId,int? month)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetDashboardTopCount(iUserId, month);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        
        [HttpGet, Route("api/ISM/GetWFDId")]
        public IHttpActionResult GetWFDId(int iWorkFlowID, int iDispositionID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetWFDId(iWorkFlowID, iDispositionID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdateIssueDisposition_InsertDtransaction")]
        public IHttpActionResult UpdateIssueDisposition_InsertDtransaction(PIUpdateDispositionRecords req)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;
                List<byte[]> fileBytesList = new List<byte[]>();
                for (int i = 0; i < req.vbDocument.Count(); i++)
                {
                    byte[] fileBytes = Convert.FromBase64String(req.vbDocument[i].ToString());
                    fileBytesList.Add(fileBytes);
                }
                var operationResult = new UserManager().UpdateIssueDisposition_InsertDtransaction(req, fileBytesList);

                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdateDispositionWFRequest")]
        public IHttpActionResult UpdateDispositionWFRequest(PIUpdateDispositionRecords req)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                List<byte[]> fileBytesList = new List<byte[]>();
                for (int i = 0; i < req.vbDocument.Count(); i++)
                {
                    byte[] fileBytes = Convert.FromBase64String(req.vbDocument[i].ToString());
                    fileBytesList.Add(fileBytes);
                }

                var operationResult = new UserManager().UpdateDispositionWFRequest(req, fileBytesList);

                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetCCEmails")]
        public IHttpActionResult GetCCEmails(int iIssueNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetCCEmails(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetDispositionCCMailsByIssue
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISM/GetDispositionCCMailsByIssue")]
        public IHttpActionResult GetDispositionCCMailsByIssue(int iDispositionNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetDispositionCCMailsByIssue(iDispositionNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetExistingDispositionsByIssueNumber")]
        public IHttpActionResult GetExistingDispositionsByIssueNumber(int iIssueNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetExistingDispositionsByIssueNumber(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetWorkflowType")]
        public IHttpActionResult GetWorkflowType(int iIssueNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetWorkflowType(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        //GetUploadedDocsForDisposition(int iIssueNumber, int iIssueWFID)
        [HttpGet, Route("api/ISM/GetUploadedDocsForDisposition")]
        public IHttpActionResult GetUploadedDocsForDisposition(int iIssueNumber, int iIssueWFID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetUploadedDocsForDisposition(iIssueNumber, iIssueWFID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetIssueNumberByWFID(int iIssueWFID)

        [HttpGet, Route("api/ISM/GetIssueNumberByWFID")]
        public IHttpActionResult GetIssueNumberByWFID(int iIssueWFID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetIssueNumberByWFID(iIssueWFID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetWorkflowDetails")]
        public IHttpActionResult GetWorkflowDetails(int iIssueWFID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetWorkflowDetails(iIssueWFID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        //GetMyQueueDisposition(int iUserId)
        [HttpGet, Route("api/ISM/GetMyQueueDisposition")]
        public IHttpActionResult GetMyQueueDisposition(int iUserId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetMyQueueDisposition(iUserId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetProductLineForPCN()
        [HttpGet, Route("api/ISM/GetProductLineForPCN")]
        public IHttpActionResult GetProductLineForPCN(int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetProductLineForPCN(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetPartNumberPCN(int iProductline)
        [HttpGet, Route("api/ISM/GetPartNumberPCN")]
        public IHttpActionResult GetPartNumberPCN(int iProductline, int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetPartNumberPCN(iProductline, iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetPartDescription(int iPartNumberID)
        [HttpGet, Route("api/ISM/GetPartDescription")]
        public IHttpActionResult GetPartDescription(int iPartNumberID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetPartDescription(iPartNumberID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetCategoryNameByPL")]
        public IHttpActionResult GetCategoryNameByPL(int iProductLineID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetCategoryNameByPL(iProductLineID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetDispositionStatusByIssueNumber")]
        public IHttpActionResult GetDispositionStatusByIssueNumber(int iIssueNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetDispositionStatusByIssueNumber(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetIssueStatusByIssueNumber(int iIssueNumber)
        [HttpGet, Route("api/ISM/GetIssueStatusByIssueNumber")]
        public IHttpActionResult GetIssueStatusByIssueNumber(int iIssueNumber)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetIssueStatusByIssueNumber(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        //==============================================================================

        #region--Lov
        [HttpGet, Route("api/ISM/GetLOVWorkFlowSample")]
        public IHttpActionResult GetLOVWorkFlowSample()
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVWorkFlow();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetLOVDispositionSample")]
        public IHttpActionResult GetLOVDispositionSample()
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVDisposition();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetLOVCategorySample")]
        public IHttpActionResult GetLOVCategorySample()
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVCategory();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetLOVProductSample")]
        public IHttpActionResult GetLOVProductSample(int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVProductSample(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetLOVPrioritySample")]
        public IHttpActionResult GetLOVPrioritySample(int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVPrioritySample(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetLOVPartNumberSample")]
        public IHttpActionResult GetLOVPartNumberSample(int iVSId)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVPartNumberSample(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetLOVStatusSample")]
        public IHttpActionResult GetLOVStatusSample()
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVStatus();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion


        #region WorkFlow
        [HttpGet, Route("api/ISM/GetLOVWorkFlow")]
        public IHttpActionResult GetLOVWorkFlow(int iWorkFlowID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVWorkFlow(iWorkFlowID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdateWorkFlowDet")]
        public IHttpActionResult UpdateWorkFlowDet(WFObj req)
        {
            try
            {

                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().UpdateWorkFlowDet(req);
                return Ok(operationResult);


            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/ValidateWorkFlowDet")]
        public IHttpActionResult ValidateWorkFlowDet(WFObj req)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().ValidateWorkFlowDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/InsertWorkFlowDet")]
        public IHttpActionResult InsertWorkFlowDet(WFObj req)
        {
            try
            {

                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().InsertWorkFlowDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region Disposition
        [HttpGet, Route("api/ISM/GetLOVDisposition")]
        public IHttpActionResult GetLOVDisposition(int iDispositionTypeID)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVDisposition(iDispositionTypeID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdateDispositionDet")]
        public IHttpActionResult UpdateDispositionDet(DPObj req)
        {
            try
            {

                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().UpdateDispositionDet(req);
                return Ok(operationResult);


            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/ValidateDispositionDet")]
        public IHttpActionResult ValidateDispositionDet(DPObj req)
        {
            try
            {
                ////ServicePointManager.Expect100Continue = true;
                ////ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       //| SecurityProtocolType.Tls11
                //       //| SecurityProtocolType.Tls12
                //       //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().ValidateDispositionDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/InsertDispositionDet")]
        public IHttpActionResult InsertDispositionDet(DPObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().InsertDispositionDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region Category
        [HttpGet, Route("api/ISM/GetLOVCategory")]
        public IHttpActionResult GetLOVCategory(int iCategoryID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVCategory(iCategoryID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetLOVALLCategory")]
        public IHttpActionResult GetLOVALLCategory()
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVALLCategory();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdateCategoryDet")]
        public IHttpActionResult UpdateCategoryDet(CObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().UpdateCategoryDet(req);
                return Ok(operationResult);


            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/ValidateCategoryDet")]
        public IHttpActionResult ValidateCategoryDet(CObj req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().ValidateCategoryDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/InsertCategoryDet")]
        public IHttpActionResult InsertCategoryDet(CObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().InsertCategoryDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region Product
        [HttpGet, Route("api/ISM/GetLOVProduct")]
        public IHttpActionResult GetLOVProduct(int iProductID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVProduct(iProductID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdateProductDet")]
        public IHttpActionResult UpdateProductDet(PRDObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().UpdateProductDet(req);
                return Ok(operationResult);


            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/ValidateProductDet")]
        public IHttpActionResult ValidateProductDet(PRDObj req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().ValidateProductDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/InsertProductDet")]
        public IHttpActionResult InsertProductDet(PRDObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().InsertProductDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region Priority
        [HttpGet, Route("api/ISM/GetLOVPriority")]
        public IHttpActionResult GetLOVPriority(int iPriorityID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVPriority(iPriorityID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdatePriorityDet")]
        public IHttpActionResult UpdatePriorityDet(PRIObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().UpdatePriorityDet(req);
                return Ok(operationResult);


            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/ValidatePriorityDet")]
        public IHttpActionResult ValidatePriorityDet(PRIObj req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().ValidatePriorityDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/InsertPriorityDet")]
        public IHttpActionResult InsertPriorityDet(PRIObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().InsertPriorityDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region PartNumber
        [HttpGet, Route("api/ISM/GetLOVPartNumber")]
        public IHttpActionResult GetLOVPartNumber(int iPartNumberID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVPartNumber(iPartNumberID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdatePartNumberDet")]
        public IHttpActionResult UpdatePartNumberDet(PNObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().UpdatePartNumberDet(req);
                return Ok(operationResult);


            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/ValidatePartNumberDet")]
        public IHttpActionResult ValidatePartNumberDet(PNObj req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().ValidatePartNumberDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/InsertPartNumberDet")]
        public IHttpActionResult InsertPartNumberDet(PNObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().InsertPartNumberDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region Status
        [HttpGet, Route("api/ISM/GetLOVStatus")]
        public IHttpActionResult GetLOVStatus(int iStatusID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVStatus(iStatusID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/UpdateStatusDet")]
        public IHttpActionResult UpdateStatusDet(SObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().UpdateStatusDet(req);
                return Ok(operationResult);


            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/ValidateStatusDet")]
        public IHttpActionResult ValidateStatusDet(SObj req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().ValidateStatusDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/InsertStatusDet")]
        public IHttpActionResult InsertStatusDet(SObj req)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;


                OperationResult operationResult = new UserManager().InsertStatusDet(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region Group
        [HttpGet, Route("api/ISM/InsertGroups")]
        //public IHttpActionResult InsertGroups(string vcGroupDescription, int bStatus, int iCreatedBy,int iVSId,int iSBUId)
        public IHttpActionResult InsertGroups(string vcGroupDescription, int bStatus, int iCreatedBy, int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;
                GroupObj req = new GroupObj();
                req.vcGroupDescription = vcGroupDescription;
                req.bStatus = bStatus;
                req.iCreatedBy = iCreatedBy;
                req.iVSId = iVSId;
                //req.iSBUId = iSBUId;
                OperationResult operationResult = new UserManager().InsertGroups(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetLOVGroup")]
        public IHttpActionResult GetLOVGroup(int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVGroup(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/UpdateGroupEdit")]
        public IHttpActionResult UpdateGroupEdit(int iGroupID, string vcGroupDescription, int bStatus)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().UpdateGroupEdit(iGroupID, vcGroupDescription, bStatus);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetGroupRecordByGroupId")]
        public IHttpActionResult GetGroupRecordByGroupId(int iGroupID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetGroupRecordByGroupId(iGroupID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/CheckCurrentGroupStatus")]
        public IHttpActionResult CheckCurrentGroupStatus(int iAssignedGroupTo)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().CheckCurrentGroupStatus(iAssignedGroupTo);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region UserGroups
        [HttpGet, Route("api/ISM/GetUserGroupsSample")]
        public IHttpActionResult GetUserGroupsSample()
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetUserGroups();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetUserGroupById")]
        public IHttpActionResult GetUserGroupById(int iUserGroupID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetUserGroupById(iUserGroupID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/InsertUserGroup")]
        public IHttpActionResult InsertUserGroup(int iUserID, int iGroupID, int iStatus, int iCreatedBy, int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().InsertUserGroup(iUserID, iGroupID, iStatus, iCreatedBy, iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/UpdateUserGroup")]
        public IHttpActionResult UpdateUserGroup(int iUserGroupID, int iUserID, int iStatus, int iUpdatedBy, int iGroupID, int isAdmin)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().UpdateUserGroup(iUserGroupID, iUserID, iStatus, iUpdatedBy, iGroupID, isAdmin);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        [HttpGet, Route("api/ISM/GetRequestedUsers")]
        public IHttpActionResult GetRequestedUsers(int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetRequestedUsers(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/UpdateUsersAccess")]
        public IHttpActionResult UpdateUsersAccess(int iUserId, int iUpdatedBy, int iGroupId, int isAdmin, int iVSId,int iRejectStatus)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().UpdateUsersAccess(iUserId, iUpdatedBy, iGroupId, isAdmin, iVSId, iRejectStatus);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetSelectedRequestUser")]
        public IHttpActionResult GetSelectedRequestUser(int iUserId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetSelectedRequestUser(iUserId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetGivenNameByEmailId")]
        public IHttpActionResult GetGivenNameByEmailId(string emailId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetGivenNameByEmailId(emailId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        [HttpPost, Route("api/ISM/EmailConfiguration")]
        public IHttpActionResult EmailConfiguration(EmailAttributes req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().EmailConfiguration(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/EmailConfigurationToApprovedUsers")]
        public IHttpActionResult EmailConfigurationToApprovedUsers(EmailAttributes req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().EmailConfigurationToApprovedUsers(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/EmailConfigurationToRejectedUsers")]
        public IHttpActionResult EmailConfigurationToRejectedUsers(EmailAttributes req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().EmailConfigurationToRejectedUsers(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }


        #endregion

        #region--NewGroupUsers
        [HttpGet, Route("api/ISM/GetGroupWithNoOfUsers")]
        public IHttpActionResult GetGroupWithNoOfUsers(int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetGroupWithNoOfUsers(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetGroupUsers(int iGroupID)
        [HttpGet, Route("api/ISM/GetGroupUsers")]
        public IHttpActionResult GetGroupUsers(int iGroupID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetGroupUsers(iGroupID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetDashboardAgingIssues")]
        public IHttpActionResult GetDashboardAgingIssues(int iUserId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardAgingIssues(iUserId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetRegistration_CCMails")]
        public IHttpActionResult GetRegistration_CCMails(int iSBUVS)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetRegistration_CCMails(iSBUVS);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        #endregion

        #region--Graphs
        [HttpGet, Route("api/ISM/GetDashboardStackChart")]
        public IHttpActionResult GetDashboardStackChart(int iUserId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardStackChart(iUserId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        [HttpGet, Route("api/ISM/GetDashboardFunctionWiseChart")]
        public IHttpActionResult GetDashboardFunctionWiseChart(int iUserId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardFunctionWiseChart(iUserId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetDashboardDonutChart")]
        public IHttpActionResult GetDashboardDonutChart(int iUserId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardDonutChart(iUserId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetAgedTicketsByCategory")]
        public IHttpActionResult GetAgedTicketsByCategory(int icategory, int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetAgedTicketsByCategory(icategory, iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        [HttpGet, Route("api/ISM/GetDashboardStackChartByProduct")]
        public IHttpActionResult GetDashboardStackChartByProduct(string productlist)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardStackChartByProduct(productlist);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetAllPartNumber")]
        public IHttpActionResult GetAllPartNumber()
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetAllPartNumber();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetDashboardStackChartByProductDate(string productlist, string startdate, string enddate)
        [HttpGet, Route("api/ISM/GetDashboardStackChartByProductDate")]
        public IHttpActionResult GetDashboardStackChartByProductDate(string productlist, string startdate, string enddate)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardStackChartByProductDate(productlist, startdate, enddate);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetDashboardStackChartBypartNumber(string partidList, string startdate, string enddate)
        [HttpGet, Route("api/ISM/GetDashboardStackChartBypartNumber")]
        public IHttpActionResult GetDashboardStackChartBypartNumber(string partidList, string startdate, string enddate)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardStackChartBypartNumber(partidList, startdate, enddate);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }


        [HttpGet, Route("api/ISM/GetPartnumberBasedOnMultipleProductLines")]
        public IHttpActionResult GetPartnumberBasedOnMultipleProductLines(string iProductLineID, int iVSid)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetPartnumberBasedOnMultipleProductLines(iProductLineID, iVSid);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/GetDashboardMultipLineChart")]
        public IHttpActionResult GetDashboardMultipLineChart(Linegraphproperties req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardMultipLineChart(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpPost, Route("api/ISM/GetDashboardMultipLineChartExport")]
        public IHttpActionResult GetDashboardMultipLineChartExport(Linegraphproperties req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetDashboardMultipLineChartExport(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        // TestGraph()
        [HttpGet, Route("api/ISM/TestGraph")]
        public IHttpActionResult TestGraph()
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().TestGraph();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }


        [HttpGet, Route("api/ISM/GetAllDispositions")]
        public IHttpActionResult GetAllDispositions()
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetAllDispositions();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        #region--WorkflowDispositions

        [HttpGet, Route("api/ISM/GetManageWorkflowDispositions")]
        public IHttpActionResult GetManageWorkflowDispositions(int iVSid)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().ManageWorkflowDispositions(iVSid);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetWorkflowDispositions")]
        public IHttpActionResult GetWorkflowDispositions(int iWorkFlowID, int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().GetWorkflowDispositions(iWorkFlowID, iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }


        [HttpGet, Route("api/ISM/InsertWorkflowDisposition")]
        public IHttpActionResult InsertWorkflowDisposition(int iWorkFlowID, string vcDispositionName, int iCreatedBy, string vcDPAlias)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //       | SecurityProtocolType.Tls11
                //       | SecurityProtocolType.Tls12
                //       | SecurityProtocolType.Ssl3;
                OperationResult operationResult = new UserManager().InsertWorkflowDisposition(iWorkFlowID, vcDispositionName, iCreatedBy, vcDPAlias);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        #endregion
        //==============================================================================
        #region--FeedbackEmail
        [HttpPost, Route("api/ISM/EmailFeedback")]//EmailFeedback
        public IHttpActionResult EmailFeedback(EmailAttributes req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().EmailFeedback(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        #endregion

        [HttpGet, Route("api/ISM/GetEmailsForInitiator_LastprocessedUser")]
        public IHttpActionResult GetEmailsForInitiator_LastprocessedUser(int iIssueNumber)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetEmailsForInitiator_LastprocessedUser(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetDashboardTopCount_details(int iUserId, int icategory)
        [HttpGet, Route("api/ISM/GetDashboardTopCount_details")]
        public IHttpActionResult GetDashboardTopCount_details(int iUserId, int icategory,int month)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetDashboardTopCount_details(iUserId, icategory, month);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //Evacs enhancements
        [HttpGet, Route("api/ISM/GetSBU")]
        public IHttpActionResult GetSBU()
        {
            try
            {
                OperationResult operationResult = new UserManager().GetSBU();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GetValueStreams(int iSBUId)
        [HttpGet, Route("api/ISM/GetValueStreams")]
        public IHttpActionResult GetValueStreams(int iSBUId)
        {
            try
            {
                OperationResult operationResult = new UserManager().GetValueStreams(iSBUId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //GroupsBasedOnVS(int iVSId)
        [HttpGet, Route("api/ISM/GroupsBasedOnVS")]
        public IHttpActionResult GroupsBasedOnVS(int iVSId)
        {
            try
            {
                OperationResult operationResult = new UserManager().GroupsBasedOnVS(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetDispositionDescription")]
        public IHttpActionResult GetDispositionDescription(int iIssueWFID)
        {
            try
            {
                OperationResult operationResult = new UserManager().GetDispositionDescription(iIssueWFID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISM/GetCRCODeatails")]
        public IHttpActionResult GetCRCODeatails(int iIssueNumber)
        {
            try
            {
                OperationResult operationResult = new UserManager().GetCRCODeatails(iIssueNumber);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //Mathu
        [HttpGet, Route("api/ISM/GetLOVALLSBU")]
        public IHttpActionResult GetLOVALLSBU()
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVALLSBU();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        [HttpGet, Route("api/ISM/GetLOVALLValueStream")]
        public IHttpActionResult GetLOVALLValueStream()
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetLOVALLValueStream();
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        //GetCategoriesBasedVS(int iVSId)
        [HttpGet, Route("api/ISM/GetCategoriesBasedVS")]
        public IHttpActionResult GetCategoriesBasedVS(int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetCategoriesBasedVS(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
       
        [HttpGet, Route("api/ISM/GetCategorById")]
        public IHttpActionResult GetCategorById(int iWorkFlowID)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().GetCategorById(iWorkFlowID);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        
        [HttpGet, Route("api/ISM/IssuesBasedOnValueStream")]
        public IHttpActionResult IssuesBasedOnValueStream(int iVSId)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().IssuesBasedOnValueStream(iVSId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }


        [HttpPost, Route("api/ISM/UpdateCategorByWorkFlowID")]
        public IHttpActionResult UpdateCategorByWorkFlowID(WFObj req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().UpdateCategorByWorkFlowID(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        //CheckWFExistance(WFObj req)
        [HttpPost, Route("api/ISM/CheckWFExistance")]
        public IHttpActionResult CheckWFExistance(WFObj req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().CheckWFExistance(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        [HttpPost, Route("api/ISM/InsertCategories")]
        public IHttpActionResult InsertCategories(WFObj req)
        {
            try
            {
                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().InsertCategories(req);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
    }
}
