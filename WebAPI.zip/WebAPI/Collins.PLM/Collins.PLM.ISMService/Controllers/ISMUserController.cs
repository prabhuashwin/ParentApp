﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    RequestController
* File Desc   :    This file contains code pertaining to deal with Application Request.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 25-NOv-2021         Venkataramana         Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using Collins.PLM.Common.Dto;
using ISM.Business;
using ISM.Business.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Script.Serialization;
using Collins.PLM.ISM.Business.Dto;

namespace Collins.PLM.ISMService.Controllers
{
    public class ISMUserController : ApiController
    {
        /// <summary>
        /// Registration
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost, Route("api/ISMUser/Register")]
        public IHttpActionResult Register(UserData req)
        {
            try
            {
                OperationResult operationResult = new UserManager().UserRegistration(req);
                //if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                //var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// CheckUserExistenceByWindowsId
        /// </summary>
        /// <param name="WindowsId"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISMUser/CheckUserExistenceByWindowsId")]
        public IHttpActionResult CheckUserExistenceByWindowsId(string WindowsId)
        {
            try
            {

                //ServicePointManager.Expect100Continue = true;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                //| SecurityProtocolType.Tls11
                //| SecurityProtocolType.Tls12
                //| SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().CheckUserExistenceByWindowsId(WindowsId);
                //var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                //return Ok(serializedData);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// CheckUserExistence
        /// </summary>
        /// <param name="vcSamAccountName"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISMUser/CheckUserExistence")]
        public IHttpActionResult CheckUserExistence(string vcSamAccountName)
        {
            try
            {
                OperationResult operationResult = new UserManager().CheckUserExistence(vcSamAccountName);
                //var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                //return Ok(serializedData);
                return Ok(operationResult.Data);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetSamAccountNameByEmail
        /// </summary>
        /// <param name="vcEmail"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISMUser/GetSamAccountNameByEmail")]
        public IHttpActionResult GetUserIdByEmail(string vcEmail)
        {
            try
            {
                var operationResult = new UserManager().GetSamAccountNameByEmail(vcEmail);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                return Ok(serializedData);
                //return Ok();
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetUserRoles
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISMUser/GetUserRoles")]
        public IHttpActionResult GetUserRoles(int iUserId)
        {
            try
            {
                //var operationResult = new UserManager().GetUserRoles(iUserId);
                //if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                //var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                //return Ok(serializedData);
                return Ok();
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetRoleName
        /// </summary>
        /// <param name="iRoleId"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISMUser/GetRoleName")]
        public IHttpActionResult GetRoleName(int iRoleId)
        {
            try
            {
                //var operationResult = new UserManager().GetRoleName(iRoleId);
                //if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                //var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                //return Ok(serializedData);
                return Ok();
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetMyQueueDet
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISMUser/GetMyQueueDet")]
        public IHttpActionResult GetMyQueueDet(int iUserId, int iVSId)
        {
            try
            {
                OperationResult operationResult = new UserManager().GetMyQueueDet(iUserId, iVSId);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetDashboardDet
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISMUser/GetDashboardDet")]
        public IHttpActionResult GetDashboardDet(int iUserId)
        {
            try
            {
                OperationResult operationResult = new UserManager().GetDashboardDet(iUserId);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetDashboardCount
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        [HttpGet, Route("api/ISMUser/GetDashboardCount")]
        public IHttpActionResult GetDashboardCount(int iUserId)
        {
            try
            {
                OperationResult operationResult = new UserManager().GetDashboardCount(iUserId);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }
        /// <summary>
        /// GetRolesByUserId
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>          
        [HttpGet, Route("api/ISMUser/GetRolesByUserId")]
        public IHttpActionResult GetRolesByUserId(int iUserId)
        {
            try
            {
                OperationResult operationResult = new UserManager().GetRolesByUserId(iUserId);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/ISMUser/UpdateToSwitchRole")]
        public IHttpActionResult UpdateToSwitchRole(int iCurrentRole, int iUserId)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                       | SecurityProtocolType.Tls11
                       | SecurityProtocolType.Tls12
                       | SecurityProtocolType.Ssl3;

                OperationResult operationResult = new UserManager().UpdateToSwitchRole(iCurrentRole, iUserId);
                return Ok(operationResult);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }


    }
}
