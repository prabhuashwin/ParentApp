﻿using Collins.PLM.Common.Dto;
using Collins.PLM.ISM.Business.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collins.PLM.ISM.Business.Interfaces
{
    public interface IRegistrationHandler
    {
        OperationResult UserRegistration(UserData req);
    }
}
