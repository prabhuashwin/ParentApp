﻿using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using Collins.PLM.DataAccessHandler;
using Collins.PLM.ISM.Business.Dto;
using ISM.Business.Dto;
using Collins.PLM.ISM.DataModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ISM.DataAccess
{
    public class UserDb
    {
        private bool _status;
        private DataSet _ds;
        private DataTable _dt;
        public string URLDashboard = System.Configuration.ConfigurationManager.AppSettings["URLDashboard"].ToString();
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        /// <summary>
        /// RegistrationUser
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public bool RegistrationUser(UserData request)
        {
            try
            {
                var pars = new SqlParameter[11];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcFirstName",
                    Value = request.vcFirstName
                };

                pars[1] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcLastName",
                    Value = request.vcLastName
                };

                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcWindowsId",
                    Value = request.vcWindowsId
                };
                pars[3] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcTitle",
                    Value = request.vcTitle
                };
                pars[4] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcEmail",
                    Value = request.vcEmail
                };
                pars[5] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcSamAccountName",
                    Value = request.vcSamAccountName
                };
                pars[6] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcGivenname",
                    Value = request.vcGivenname
                };
                //@iGroupID
                pars[7] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iGroupID",
                    Value = request.GroupPickList
                };
                pars[8] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iSBUId",
                    Value = request.iSBUId
                };
                pars[9] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVSId",
                    Value = request.iVSId
                };
                pars[10] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };
                int returnValue; int executedVal;

                executedVal = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "USP_ISM_RegisterUser", pars));
                returnValue = Convert.ToInt32(pars[10].Value);
                _status = returnValue == 1;
                return _status;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// CheckUserExistenceByWindowsId
        /// </summary>
        /// <param name="vcWindowsId"></param>
        /// <returns></returns>
        public DataTable CheckUserExistenceByWindowsId(string vcWindowsId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcWindowsId",
                    Value = vcWindowsId
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_checkWindowsIdExistance", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_checkWindowsIdExistance", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// CheckUserExistence
        /// </summary>
        /// <param name="vcSamAccountName"></param>
        /// <returns></returns>
        public DataTable CheckUserExistence(string vcSamAccountName)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcSamAccountName",
                    Value = vcSamAccountName
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_checkEmailExistance", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_checkEmailExistance", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetUserIdByEmail
        /// </summary>
        /// <param name="vcEmail"></param>
        /// <returns></returns>
        public DataTable GetUserIdByEmail(string vcEmail)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@vcEmail", Value = vcEmail };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetUserIdByEmail", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetUserIdByEmail", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// InitiateRequest
        /// </summary>
        /// <param name="req"></param>
        /// <param name="fileBytesList"></param>
        /// <returns></returns>
        public DataTable InitiateRequest(ISMRequestInitiation req, List<byte[]> fileBytesList)
        {
            try
            {
                DataTable tbl_ISM_Files_Type_Data = new DataTable();

                tbl_ISM_Files_Type_Data.Columns.Add("iInsId");
                tbl_ISM_Files_Type_Data.Columns.Add("vcFileName");
                tbl_ISM_Files_Type_Data.Columns.Add("isLastCopy");
                tbl_ISM_Files_Type_Data.Columns.Add("vbDocument", typeof(SqlBinary));
                tbl_ISM_Files_Type_Data.Columns.Add("iDocFlag");
                if (req.vbDocument != null)
                {
                    for (int i = 0; i < req.vbDocument.Count(); i++)
                    {
                        tbl_ISM_Files_Type_Data.Rows.Add(
                                    0,
                                   req.vcFileName[i],
                                   req.isLastCopy,
                                   fileBytesList[i],
                                   req.iDocFlag
                            );
                    }
                }

                DataTable tbl_ISM_CC_Email_Type_Data = new DataTable();
                tbl_ISM_CC_Email_Type_Data.Columns.Add("iIssueNumber");
                tbl_ISM_CC_Email_Type_Data.Columns.Add("vcCCEmail");
                if (req.vcCCEmail.Count() != 0)
                {
                    for (int i = 0; i < req.vcCCEmail.Count(); i++)
                    {
                        tbl_ISM_CC_Email_Type_Data.Rows.Add(
                                    0,
                                   req.vcCCEmail[i]
                            );
                    }
                }
                var pars = new SqlParameter[21];

                pars[0] = new SqlParameter();
                pars[0].ParameterName = "@tbl_ISM_Files_Type_Data";
                pars[0].Value = tbl_ISM_Files_Type_Data;

                pars[1] = new SqlParameter();
                pars[1].ParameterName = "@tbl_ISM_CC_Email_Type_Data";
                pars[1].Value = tbl_ISM_CC_Email_Type_Data;

                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iWorkFlowName",
                    Value = req.iWorkFlowName
                };
                if (req.vcQNNumber == null)
                {
                    pars[3] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.VarChar,
                        ParameterName = "@vcQNNumber",
                        Value = DBNull.Value
                    };
                }
                else
                {
                    pars[3] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.VarChar,
                        ParameterName = "@vcQNNumber",
                        Value = req.vcQNNumber
                    };
                }

                pars[4] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = req.iUserId
                };
                if (req.dECD == "NaN/NaN/NaN")
                {
                    pars[5] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.VarChar,
                        ParameterName = "@dECD",
                        Value = DBNull.Value
                    };
                }
                else
                {
                    pars[5] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.VarChar,
                        ParameterName = "@dECD",
                        Value = req.dECD
                    };
                }

                //pars[6] = new SqlParameter
                //{
                //    SqlDbType = SqlDbType.Int,
                //    ParameterName = "@iLastProcessedUser",
                //    Value = req.iLastProcessedUser
                //};
                pars[6] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iProductline",
                    Value = req.iProductline
                };
                pars[7] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iPartNumber",
                    Value = req.iPartNumber
                };
                if (req.iCategory == null)
                {
                    pars[8] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.Int,
                        ParameterName = "@iCategory",
                        Value = DBNull.Value
                    };
                }
                else
                {
                    pars[8] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.Int,
                        ParameterName = "@iCategory",
                        Value = req.iCategory
                    };
                }
                if (req.iPriority == null)
                {
                    pars[9] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.Int,
                        ParameterName = "@iPriority",
                        Value = DBNull.Value
                    };
                }
                else
                {
                    pars[9] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.Int,
                        ParameterName = "@iPriority",
                        Value = req.iPriority
                    };
                }

                pars[10] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iActivityOwner",
                    Value = req.iActivityOwner
                };
                pars[11] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcIssueDescription",
                    Value = req.vcIssueDescription.Replace(Environment.NewLine, "<br />")
                };
                pars[12] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iAssignedGroupTo",
                    Value = req.iAssignedGroupTo
                };
                pars[13] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iAssignTo",
                    Value = req.iAssignTo
                };//

                pars[14] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcPartDescription",
                    Value = req.vcPartDescription
                };
                //@vcPCNNumber
                pars[15] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcPCNNumber",
                    Value = req.vcPCNNumber
                };

                pars[16] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcSerialNumber",
                    Value = req.vcSerialNumber
                };
                pars[17] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcIssueTitle",
                    Value = req.vcIssueTitle
                };
                //iVSId
                pars[18] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@iVSId",
                    Value = req.iVSId
                };
                if (req.vcOtherPartNumber == "")
                {
                    pars[19] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.NVarChar,
                        ParameterName = "@vcOtherPartNumber",
                        Value = DBNull.Value
                    };
                }
                else
                {
                    pars[19] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.NVarChar,
                        ParameterName = "@vcOtherPartNumber",
                        Value = req.vcOtherPartNumber
                    };
                }
                
                pars[20] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };
                //int result;
                int returnValue;
                string iIssueNumber = string.Empty;
                string vcVS = string.Empty;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_InsertIssueRequest", pars);
                    returnValue = Convert.ToInt32(pars[20].Value);
                    if (returnValue == 1)
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.Append("<h2><center>ISM- Dashboard Tool: Issue created</center></h2>");
                        sb.Append("<p>Hi " + req.iAssignToText + ",</p> ");
                        sb.Append("<p>User has submitted the request with below details");
                        sb.Append("<html><head><style> th, td {border: 1px solid black;}</style></head><body>");
                        sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='5'><center><h4>Issue Details</h4></center></td></tr>");
                        sb.Append("<tr><th style='text-align:left'>Issue Number</th><td colspan='4'>" + _ds.Tables[0].Rows[0]["appendedIssueNumber"].ToString() + "</ td ></ tr > ");

                        sb.Append("<tr><th style='text-align:left'>Productline</th><td colspan='4'>" + req.iProductlineText + "</ td ></ tr > ");

                        if (req.iPartNumberText == "Others")
                            sb.Append("<tr><th style='text-align:left'>PartNumber</th><td colspan='4'>" + req.vcOtherPartNumber + "</ td ></ tr > ");
                        else
                            sb.Append("<tr><th style='text-align:left'>PartNumber</th><td colspan='4'>" + req.iPartNumberText + "</ td ></ tr > ");
                        
                        sb.Append("<tr><th style='text-align:left'>PartDescription</th><td colspan='4'>" + req.vcPartDescription + "</ td ></ tr > ");
                        sb.Append("<tr><th style='text-align:left'>Priority</th><td colspan='4'>" + req.iPriorityText + "</ td ></ tr > ");
                        sb.Append("<tr><th style='text-align:left'>Assigned Group</th><td colspan='4'>" + req.iAssignedGroupToText + "</ td ></ tr > ");
                        sb.Append("<tr><th style='text-align:left'>Subject/Issue Title</th><td colspan='4'>" + req.vcIssueTitle + "</ td ></ tr > ");
                        sb.Append("<tr><th style='text-align:left'>Assigned By</th><td colspan='4'>" + req.vcUserName + "</ td ></ tr > ");
                        sb.Append("<tr><th style='text-align:left'>Issue Status</th><td colspan='4'>In Progress</ td ></ tr > ");//Change required
                        sb.Append("</table></body></html>");
                        sb.Append("<br /><b>Issue Description: </b>" + req.vcIssueDescription);
                        sb.Append("<br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                        sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");

                        string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                        string subject = "Issue Created-" + _ds.Tables[0].Rows[0]["appendedIssueNumber"].ToString() + " for " + req.iProductlineText;
                        string toAddress = req.toMail;
                        string toCC = string.Join(",", req.vcCCEmail);
                        iIssueNumber = _ds.Tables[0].Rows[0]["appendedIssueNumber"].ToString();
                        vcVS = _ds.Tables[0].Rows[0]["vcVS"].ToString();
                        var emailhelper = new EmailNotification();
                        emailhelper.SendMailToAdmin(toreply, toAddress, toCC.Trim(), subject, sb.ToString(), true);
                    }
                }
                DataTable dtIssuenumAndRetVal = new DataTable();
                dtIssuenumAndRetVal.Columns.Add("returnValue");
                dtIssuenumAndRetVal.Columns.Add("appendedIssueNumber");
                dtIssuenumAndRetVal.Columns.Add("vcVS");

                dtIssuenumAndRetVal.Rows.Add(returnValue, iIssueNumber, vcVS);
                return dtIssuenumAndRetVal;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// UpdateRequest
        /// </summary>
        /// <param name="req"></param>
        /// <param name="fileBytesList"></param>
        /// <returns></returns>
        public int UpdateRequest(ISMRequestUpdation req, List<byte[]> fileBytesList)
        {
            try
            {
                #region--ISM_Disposition Data Table
                DataTable tbl_ISM_Disposition_Type_Data = new DataTable();
                tbl_ISM_Disposition_Type_Data.Columns.Add("iIssueNumber");
                tbl_ISM_Disposition_Type_Data.Columns.Add("iWorkFlowDispotionId");
                tbl_ISM_Disposition_Type_Data.Columns.Add("iStatus");
                tbl_ISM_Disposition_Type_Data.Columns.Add("iAssignedTo");
                tbl_ISM_Disposition_Type_Data.Columns.Add("iAssignedGroup");
                tbl_ISM_Disposition_Type_Data.Columns.Add("iActivityOwner");
                tbl_ISM_Disposition_Type_Data.Columns.Add("iLastProcessedBy");
                tbl_ISM_Disposition_Type_Data.Columns.Add("vcComments");

                if (req.vbDocument != null)
                {
                    for (int i = 0; i < req.WFDId.Count(); i++)//iWorkFlowDispotionId
                    {
                        tbl_ISM_Disposition_Type_Data.Rows.Add(
                                    req.iIssueNumber,
                                    req.WFDId[i],//iWorkFlowDispotionId
                                    0,
                                    req.iAssignedTo[i],
                                    req.iAssignedGroup[i],
                                    0,
                                    req.iLastProcessedUser,
                                    req.vcComments[i]
                            );
                    }
                }
                #endregion

                #region--ISM_Files Data Table
                DataTable tbl_ISM_Files_Type_Data = new DataTable();
                tbl_ISM_Files_Type_Data.Columns.Add("iInsId");
                tbl_ISM_Files_Type_Data.Columns.Add("vcFileName");
                tbl_ISM_Files_Type_Data.Columns.Add("isLastCopy");
                tbl_ISM_Files_Type_Data.Columns.Add("vbDocument", typeof(SqlBinary));
                tbl_ISM_Files_Type_Data.Columns.Add("iDocFlag");
                if (req.vbDocument != null)
                {
                    for (int i = 0; i < req.vbDocument.Count(); i++)
                    {
                        tbl_ISM_Files_Type_Data.Rows.Add(
                                    req.iIssueNumber,
                                   req.vcFileName[i],
                                   req.isLastCopy,
                                   fileBytesList[i],
                                   req.iDocFlag
                            );
                    }
                }
                #endregion

                var pars = new SqlParameter[16];

                pars[0] = new SqlParameter();
                pars[0].ParameterName = "@tbl_ISM_Disposition_Type_Data";
                pars[0].Value = tbl_ISM_Disposition_Type_Data;
                //return 0;
                pars[1] = new SqlParameter();
                pars[1].ParameterName = "@tbl_ISM_Files_Type_Data";
                pars[1].Value = tbl_ISM_Files_Type_Data;

                //pars[2] = new SqlParameter();
                //pars[2].ParameterName = "@tbl_ISM_Disposition_CC_Email_Type_Data";
                //pars[2].Value = tbl_ISM_Disposition_CC_Email_Type_Data;

                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueNumber",
                    Value = req.iIssueNumber
                };

                pars[3] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@iUserId",
                    Value = req.iUserId
                };
                pars[4] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iDispositionType",
                    Value = req.iDispositionType
                };
                pars[5] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@vcComments",
                    Value = req.T_vcComments
                };
                pars[6] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iAssignedGroupTo",
                    Value = req.T_iAssignGroup
                };
                pars[7] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iAssignTo",
                    Value = req.T_iAssignTo
                };
                pars[8] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iStatus",
                    Value = req.iStatus
                };
                pars[9] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcSolutionForClosed",
                    Value = req.vcSolutionForClosed
                };
                pars[10] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_One",
                    Value = req.vcCRCO_One
                };
                pars[11] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_Two",
                    Value = req.vcCRCO_Two
                };
                pars[12] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_Three",
                    Value = req.vcCRCO_Three
                };
                pars[13] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_Four",
                    Value = req.vcCRCO_Four
                };
                pars[14] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_Five",
                    Value = req.vcCRCO_Five
                };
                pars[15] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };
                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateIssueRequest", pars));
                    returnValue = Convert.ToInt32(pars[15].Value);
                    if (returnValue == 1)
                    {

                        var WFIDpars = new SqlParameter[2];

                        WFIDpars[0] = new SqlParameter
                        {
                            SqlDbType = SqlDbType.Int,
                            ParameterName = "@iIssueNumber",
                            Value = req.iIssueNumber
                        };

                        WFIDpars[1] = new SqlParameter()
                        {
                            SqlDbType = SqlDbType.Int,
                            ParameterName = "@ReturnValue",
                            Direction = ParameterDirection.Output
                        };

                        _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetIssueWFIDbyIssueId", WFIDpars);
                        returnValue = Convert.ToInt32(WFIDpars[1].Value);
                        if (_ds.Tables[0].Rows.Count > 0)
                        {
                            #region--tbl_ISM_DtransactionDisposition_Type_Data Data Table
                            DataTable tbl_ISM_DtransactionDisposition_Type_Data = new DataTable();
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("iIssueNumber");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("iWorkFlowDispotionId");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("vcDispositionTitle");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("iStatus");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("iAssignedTo");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("iAssignedGroup");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("iActivityOwner");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("iLastProcessedBy");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("vcComments");
                            tbl_ISM_DtransactionDisposition_Type_Data.Columns.Add("iIssueWFID");
                            //req.WFDId is WorkflowDispositionID (Combination of WFtype and Disposition(Like Concession or ...))
                            //req.iWorkFlowDispotionId is disposition ID (ConcessionId or ECR Id .....)
                            if (req.WFDId.Count() > 0)
                            {
                                int countOfAddingDispositions = Convert.ToInt32(_ds.Tables[0].Rows.Count) - Convert.ToInt32(req.iWorkFlowDispotionId.Count());
                                for (int i = 0; i < req.WFDId.Count(); i++)//iWorkFlowDispotionId
                                {
                                    tbl_ISM_DtransactionDisposition_Type_Data.Rows.Add(
                                                req.iIssueNumber,
                                                req.WFDId[i],//iWorkFlowDispotionId
                                                req.vcDispositionTitle[i],
                                                0,
                                                req.iAssignedTo[i],
                                                req.iAssignedGroup[i],
                                                0,
                                                req.iLastProcessedUser,
                                                req.vcComments[i],
                                                Convert.ToInt32(_ds.Tables[0].Rows[i + countOfAddingDispositions]["iIssueWFID"].ToString())
                                        );
                                }
                            }
                            #endregion

                            #region--Email
                            DataTable tbl_ISM_Disposition_CC_Email_Type_Data = new DataTable();
                            tbl_ISM_Disposition_CC_Email_Type_Data.Columns.Add("iDispositionNumber");
                            tbl_ISM_Disposition_CC_Email_Type_Data.Columns.Add("vcCCEmail");
                            if (req.d_vcCCEmails.Count() != 0)
                            {
                                int countOfAddingDispositions = Convert.ToInt32(_ds.Tables[0].Rows.Count) - Convert.ToInt32(req.iWorkFlowDispotionId.Count());
                                for (int i = 0; i < req.d_vcCCEmails.Count(); i++)
                                {
                                    tbl_ISM_Disposition_CC_Email_Type_Data.Rows.Add(
                                               Convert.ToInt32(_ds.Tables[0].Rows[i + countOfAddingDispositions]["iIssueWFID"].ToString()),
                                               req.d_vcCCEmails[i].Trim()
                                        );
                                }
                            }
                            #endregion

                            var DTranEmailpars = new SqlParameter[3];

                            DTranEmailpars[0] = new SqlParameter();
                            DTranEmailpars[0].ParameterName = "@tbl_ISM_DtransactionDisposition_Type_Data";
                            DTranEmailpars[0].Value = tbl_ISM_DtransactionDisposition_Type_Data;

                            DTranEmailpars[1] = new SqlParameter();
                            DTranEmailpars[1].ParameterName = "@tbl_ISM_Disposition_CC_Email_Type_Data";
                            DTranEmailpars[1].Value = tbl_ISM_Disposition_CC_Email_Type_Data;

                            DTranEmailpars[2] = new SqlParameter()
                            {
                                SqlDbType = SqlDbType.Int,
                                ParameterName = "@ReturnValue",
                                Direction = ParameterDirection.Output
                            };

                            result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_DtransactionDisposition", DTranEmailpars));
                            returnValue = Convert.ToInt32(DTranEmailpars[2].Value);

                            #region--EmailConfig
                            string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                            string subject = string.Empty;
                            string toAddress = string.Empty;
                            string toCC = string.Empty;
                            var emailhelper = new EmailNotification();
                            if (req.toMail != "" && req.toMail != null)
                            {
                                //check
                                string IssueWorkflowString = req.appendedIssueNumber.ToString().Split('-')[0];

                                StringBuilder sb = new StringBuilder();
                                sb.Append("<h2><center>ISM- Dashboard Tool: User updated the Request</center></h2>");
                                sb.Append("<p>Hi " + req.T_iAssignToText + ",</p> ");
                                sb.Append("<p>User has updated the request with below details");
                                sb.Append("<html><head><style> th, td {border: 1px solid black;}</style></head><body>");
                                sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='5'><center><h4>Issue Details</h4></center></td></tr>");
                                sb.Append("<tr><th style='text-align:left'>Issue Number</th><td colspan='4'>" + IssueWorkflowString + req.iIssueNumber + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>Productline</th><td colspan='4'>" + req.vcProductName + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>PartNumber</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>PartDescription</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");
                               
                                if (req.T_iAssignGroupText != "" && req.T_iAssignGroupText != null)
                                    sb.Append("<tr><th style='text-align:left'>Assigned Group</th><td colspan='4'>" + req.T_iAssignGroupText + "</ td ></ tr > ");
                                if (req.T_iAssignToText != "" && req.T_iAssignToText != null)
                                    sb.Append("<tr><th style='text-align:left'>Assigned To</th><td colspan='4'>" + req.T_iAssignToText + "</ td ></ tr > ");

                                sb.Append("</table></body></html>");

                                if (req.vcIssueDescription != "")
                                    sb.Append("<br /><b>Actual Issue Description: </b>" + req.vcIssueDescription);

                                sb.Append("<br /><br /><b>Last Comments: </b>" + req.T_vcCommentsText);
                                sb.Append("<br /><br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                                sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                                subject = "Updated the Issue- " + req.appendedIssueNumber + " for " + req.vcProductName;

                                toAddress = req.toMail;
                                //toCC = string.Join(",", req.vcCCEmail);

                                for (int i = 0; i < req.vcCCEmail.Count(); i++)
                                {
                                    req.vcCCEmail[i] = req.vcCCEmail[i].Trim();
                                }

                                toCC = string.Join(",", req.vcCCEmail);

                                emailhelper.SendMailToAdmin(toreply, toAddress, toCC.Trim(), subject, sb.ToString(), true);
                            }
                            else
                            {
                                var parsIWFId = new SqlParameter[1];
                                parsIWFId[0] = new SqlParameter
                                {
                                    SqlDbType = SqlDbType.VarChar,
                                    ParameterName = "@iIssueNumber",
                                    Value = req.iIssueNumber
                                };

                                using (var conIWFId = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                                {
                                    if (req.WFDId.Count() > 1)
                                    {
                                        _ds = SqlHelper.ExecuteDataset(conIWFId, CommandType.StoredProcedure, "usp_ISM_GetDispositionWFID", parsIWFId);
                                    }

                                    else
                                    {
                                        _ds = SqlHelper.ExecuteDataset(conIWFId, CommandType.StoredProcedure, "usp_ISM_GetIssueWFIDbyIssueIdSingle", parsIWFId);
                                        var parsIWFIdRef = new SqlParameter[1];
                                        parsIWFIdRef[0] = new SqlParameter
                                        {
                                            SqlDbType = SqlDbType.VarChar,
                                            ParameterName = "@iIssueWFID",
                                            Value = _ds.Tables[0].Rows[0]["iIssueWFID"]
                                        };
                                        _ds = SqlHelper.ExecuteDataset(conIWFId, CommandType.StoredProcedure, "usp_ISM_GetDispositionWFIDSingle", parsIWFIdRef);
                                    }
                                }
                                for (int i = 0; i < req.group_ToEmail.Count(); i++)
                                {
                                    string DispositionString = _ds.Tables[0].Rows[i]["iIssueWFID"].ToString().Split('-')[0];
                                    StringBuilder sb = new StringBuilder();
                                    sb.Append("<h2><center>ISM- Dashboard Tool: Disposition Created</center></h2>");
                                    sb.Append("<p>Hi " + req.iAssignedToText[i] + ",</p> ");
                                    sb.Append("<p>User has updated the request with below details");
                                    sb.Append("<html><head><style> th, td {border: 1px solid black;}</style></head><body>");
                                    sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='5'><center><h4>Disposition Details</h4></center></td></tr>");
                                    sb.Append("<tr><th style='text-align:left'>Disposition Number</th><td colspan='4'>" + _ds.Tables[0].Rows[i]["vcWFAliasName"] + "</ td ></ tr > ");//Changed
                                    //sb.Append("<tr><th style='text-align:left'>Disposition Number</th><td colspan='4'>" + DispositionString + req.iIssueNumber.ToString() + "</ td ></ tr > ");
                                    sb.Append("<tr><th style='text-align:left'>Issue Number</th><td colspan='4'>" + _ds.Tables[0].Rows[i]["vcWFAliasName"].ToString().Substring(0, _ds.Tables[0].Rows[i]["vcWFAliasName"].ToString().Length - 3) + " </ td ></ tr > ");
                                    sb.Append("<tr><th style='text-align:left'>Productline</th><td colspan='4'>" + req.vcProductName + "</ td ></ tr > ");
                                    sb.Append("<tr><th style='text-align:left'>PartNumber</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");
                                    //if (req.vcCategoryName != "")
                                    //{
                                    //    sb.Append("<tr><th style='text-align:left'>Category</th><td colspan='4'>" + req.vcCategoryName + "</ td ></ tr > ");
                                    //}
                                    if (req.iAssignedGroupText[i] != "" && req.iAssignedGroupText[i] != null)
                                        sb.Append("<tr><th style='text-align:left'>Assigned Group</th><td colspan='4'>" + req.iAssignedGroupText[i] + "</ td ></ tr > ");
                                    if (req.iAssignedToText[i] != "" && req.iAssignedToText[i] != null)
                                        sb.Append("<tr><th style='text-align:left'>Assigned To</th><td colspan='4'>" + req.iAssignedToText[i] + "</ td ></ tr > ");
                                    sb.Append("<tr><th style='text-align:left'>Status</th><td colspan='4'>" + _ds.Tables[0].Rows[i]["vcStatusDescription"].ToString() + " </ td ></ tr > ");
                                    sb.Append("</table></body></html>");

                                    if (req.vcIssueDescription != "")
                                        sb.Append("<br /><b>Actual Issue Description: </b>" + req.vcIssueDescription);

                                    sb.Append("<br /><br /><b>Last Comments: </b>" + req.vcComments[i]);

                                    sb.Append("<br /><br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                                    sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                                    //subject = "User has updated the request- " + _ds.Tables[0].Rows[i]["iIssueWFID"] + " for " + req.vcProductName;
                                    //subject = "Disposition created- " + _ds.Tables[0].Rows[i]["vcWFAliasName"] + DispositionString + " for " + req.vcProductName;
                                    subject = "Disposition created- " + _ds.Tables[0].Rows[i]["vcWFAliasName"] + " for " + req.vcProductName;
                                    toCC = string.Join(",", req.d_vcCCEmails[i]);
                                    if (toCC == "")
                                        toCC = req.vcCCEmail[0].ToString();
                                    else
                                        toCC = toCC + "," + req.vcCCEmail[0].ToString();
                                    emailhelper.SendMailToAdmin(toreply, req.group_ToEmail[i].Trim(), toCC.Trim(), subject, sb.ToString(), true);
                                }
                            }
                            #endregion
                        }
                        else//Edit page-->Continue Workflow
                        {
                            string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                            string subject = string.Empty;
                            string toAddress = string.Empty;
                            string toCC = string.Empty;
                            var emailhelper = new EmailNotification();
                            if (req.toMail != "")
                            {
                                StringBuilder sb = new StringBuilder();
                                sb.Append("<h2><center>ISM- Dashboard Tool: Updated the Issue</center></h2>");
                                sb.Append("<p>Hi " + req.T_iAssignToText + ",</p> ");
                                sb.Append("<p>User has updated the request with below details");
                                sb.Append("<html><head><style> th, td {border: 1px solid black;}</style></head><body>");
                                sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='5'><center><h4>Issue Details</h4></center></td></tr>");
                                sb.Append("<tr><th style='text-align:left'>Issue Number</th><td colspan='4'>" + req.appendedIssueNumber + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>Productline</th><td colspan='4'>" + req.vcProductName + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>PartNumber</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>Priority</th><td colspan='4'>" + req.vcPriorityName + "</ td ></ tr > ");
                                
                                if (req.T_iAssignGroupText != "")
                                    sb.Append("<tr><th style='text-align:left'>Assigned Group</th><td colspan='4'>" + req.T_iAssignGroupText + "</ td ></ tr > ");
                                if (req.T_iAssignToText != "")//change...
                                    sb.Append("<tr><th style='text-align:left'>Assigned By</th><td colspan='4'>" + req.AssignedByText + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>Issue Status</th><td colspan='4'>" + req.iStatusText + "</ td ></ tr > ");
                                sb.Append("</table></body></html><br />");

                                if (req.vcIssueDescription != "")
                                    sb.Append("<br /><b>Actual Issue Description: </b>" + req.vcIssueDescription);

                                sb.Append("<br /><br /><b>Last comments: </b>" + req.T_vcCommentsText);
                                //sb.Append("<br /><b>Last comments: </b><p>" + req.T_vcCommentsText + "</p>");
                                sb.Append("<br /><br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                                sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                                subject = "Updated the Issue- " + req.appendedIssueNumber + " for " + req.vcProductName;

                                toAddress = req.toMail;

                                for (int i = 0; i < req.vcCCEmail.Count(); i++)
                                {
                                    req.vcCCEmail[i] = req.vcCCEmail[i].Trim();
                                }

                                toCC = string.Join(",", req.vcCCEmail);

                                emailhelper.SendMailToAdmin(toreply, toAddress, toCC.Trim(), subject, sb.ToString(), true);
                            }
                            if (req.vcCCEmail.Count() > 0 && req.toMail == "")//Closed
                            {
                                StringBuilder sb = new StringBuilder();
                                sb.Append("<h2><center>ISM- Dashboard Tool: Updated the Issue</center></h2>");
                                sb.Append("<p>Hi " + req.T_iAssignToText + ",</p> ");
                                sb.Append("<p>User has updated the request with below details");
                                sb.Append("<html><head><style> th, td {border: 1px solid black;}</style></head><body>");
                                sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='5'><center><h4>Issue Details</h4></center></td></tr>");
                                sb.Append("<tr><th style='text-align:left'>Issue Number</th><td colspan='4'>" + req.appendedIssueNumber + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>Productline</th><td colspan='4'>" + req.vcProductName + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>PartNumber</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");
                                //sb.Append("<tr><th style='text-align:left'>Category</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");
                                if (req.iStatus == 4)
                                    sb.Append("<tr><th style='text-align:left'>Closed By</th><td colspan='4'>" + req.AssignedByText + "</ td ></ tr > ");

                                if (req.T_iAssignGroupText != "")
                                    sb.Append("<tr><th style='text-align:left'>Assigned Group</th><td colspan='4'>" + req.T_iAssignGroupText + "</ td ></ tr > ");
                                if (req.T_iAssignToText != "")//change...
                                    sb.Append("<tr><th style='text-align:left'>Assigned By</th><td colspan='4'>" + req.AssignedByText + "</ td ></ tr > ");
                                sb.Append("<tr><th style='text-align:left'>Issue Status</th><td colspan='4'>" + req.iStatusText + "</ td ></ tr > ");
                                sb.Append("</table></body></html><br />");

                                if (req.vcIssueDescription != "")
                                    sb.Append("<br /><b>Actual Issue Description: </b>" + req.vcIssueDescription);

                                sb.Append("<br /><br /><b>Last comments: </b>" + req.T_vcCommentsText);
                                //sb.Append("<br /><b>Last comments: </b><p>" + req.T_vcCommentsText + "</p>");
                                sb.Append("<br /><br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                                sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                                subject = "Updated the Issue- " + req.appendedIssueNumber + " for " + req.vcProductName;

                                toAddress = req.vcCCEmail[0].Trim();

                                for (int i = 0; i < req.vcCCEmail.Count(); i++)
                                {
                                    req.vcCCEmail[i] = req.vcCCEmail[i].Trim();
                                }

                                toCC = string.Join(",", req.vcCCEmail);

                                emailhelper.SendMailToAdmin(toreply, toAddress, toCC.Trim(), subject, sb.ToString(), true);
                            }
                        }
                    }
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetAssignGroup
        /// </summary>
        /// <returns></returns>
        public DataTable GetAssignGroup(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetGroupsBasedVS", pars);
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iGroupID, vcGroupDescription from tbl_ISM_Groups where iGroupID!=5 and bStatus =1");               
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetGroups(int iVSId)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select G.iGroupID, G.vcGroupDescription from tbl_ISM_Groups G inner join tbl_ISM_Groups_VS GVS on G.iGroupID=GVS.iGroupid where bStatus =1 and GVS.iVSId=" + iVSId);//iGroupID!=5 and
                //select iGroupID, vcGroupDescription from tbl_ISM_Groups where bStatus =1
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetAllUsers(int iVSId)
        {
            try
            {
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iUserId,vcGivenname from tbl_ISM_User where iStatus=1");

                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select uvs.iUserId,u.vcGivenname from tbl_ISM_UserVS uvs inner join   tbl_ISM_User u on u.iUserId=uvs.iUserId where u.iStatus=1 and uvs.iVSId="+ iVSId);                
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// GetProductLine
        /// </summary>
        /// <returns></returns>
        public DataTable GetProductLine(int iCategory)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT iProductLineID, vcProductName  FROM tbl_ISM_ProductLine where iCategoryID=" + iCategory + " and bIsActive =1");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "SELECT iProductLineID, vcProductName  FROM tbl_ISM_ProductLine where iCategoryID=" + iCategory + " and bIsActive =1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetPartNumber
        /// </summary>
        /// <returns></returns>
        public DataTable GetPartNumber(int iProductline, int iCategory)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT iPartNumberID, vcPartNumberName  FROM tbl_ISM_PartNumber where iProductLineID=" + iProductline + " and iCategoryID=" + iCategory + " and bIsActive =1");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "SELECT iPartNumberID, vcPartNumberName  FROM tbl_ISM_PartNumber where iProductLineID=" + iProductline + " and iCategoryID=" + iCategory + " and bIsActive =1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetCategory
        /// </summary>
        /// <returns></returns>
        public DataTable GetCategory()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT iCategoryID, vcCategoryName  FROM tbl_ISM_Category where bIsActive =1");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "SELECT iCategoryID, vcCategoryName  FROM tbl_ISM_Category where bIsActive =1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetUserGroups
        /// </summary>
        /// <param name="iGroupID"></param>
        /// <returns></returns>
        public DataTable GetUserGroups(int iGroupID, int iVSId)
        {
            try
            {//usp_ISM_GetGroupUsersBasedOnVS

                var pars = new SqlParameter[2];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iGroupID", Value = iGroupID };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetGroupUsersBasedOnVS", pars);

                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select ug.iUserGroupID,ug.iUserID,ug.iGroupID,us.vcGivenname from tbl_ISM_UserGroups ug inner join tbl_ISM_User us on ug.iUserID = us.iUserId where ug.iGroupID = " + iGroupID + " and ug.iStatus = 1");

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetPriority
        /// </summary>
        /// <returns></returns>
        public DataTable GetPriority(int iVSId)
        {
            try
            {//usp_ISM_GetPriority
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetPriority", pars);
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT iPriorityID, vcPriorityName  FROM tbl_ISM_Priority where bIsActive =1");

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetMyQueueDet
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public DataTable GetMyQueueDet(int iUserId, int iVSId)
        {
            try
            {
                var pars = new SqlParameter[2];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iUserId", Value = iUserId };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetMyQueueDet", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetDashboardDet
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public DataTable GetDashboardDet(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iUserId", Value = iUserId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardDet", pars);//usp_ISM_GetDashboardDet
                _dt = _ds.Tables[0];//usp_ISM_GetDashboardAgingIssues
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetDashboardCount
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public DataTable GetDashboardCount(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iUserId", Value = iUserId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardCount", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetIssueDetails
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        public DataTable GetIssueDetails(int iIssueNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueNumber", Value = iIssueNumber };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetIssueDetails", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetIssueDetails", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// DisplayUploadedFiles
        /// </summary>
        /// <param name="iInsId"></param>
        /// <returns></returns>
        public DataTable DisplayUploadedFiles(int iInsId)
        {
            try
            {
                var pars = new SqlParameter[2];

                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iInsId",
                    Value = iInsId
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetUploadedDocs", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetUploadedDocs", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetBasestring
        /// </summary>
        /// <param name="iDocId"></param>
        /// <returns></returns>
        public DataTable GetBasestring(int iDocId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iDocId",
                    Value = iDocId
                };
                DataSet ds;
                DataTable dt;
                ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetFileString", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetFileString", pars);
                //}
                dt = ds.Tables[0];
                return dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetDipositionType
        /// </summary>
        /// <returns></returns>
        public DataTable GetDipositionType(int iWorkFlowID, int iVSId)
        {
            try
            {
                var pars = new SqlParameter[2];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iWorkFlowID", Value = iWorkFlowID };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetWorkflowDispositions", pars);
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select WD.iWorkFlowID, WD.iDispositionID,DT.vcDispositionName from tbl_ISM_WorkFlowDisposition WD inner join tbl_ISM_DipositionType DT on WD.iDispositionID = DT.iDispositionTypeID where WD.iWorkFlowID = " + iWorkFlowID + " and iStatus = 1");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetHistory
        /// </summary>
        /// <param name="iActivityOwner"></param>
        /// <returns></returns>
        public DataTable GetHistory(int iIssueNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueNumber", Value = iIssueNumber };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetHistory", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetHistory", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// GetDispositionHistory
        /// </summary>
        /// <param name="iIssueWFID"></param>
        /// <returns></returns>
        public DataSet GetDispositionHistory(int iIssueWFID)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueWFID", Value = iIssueWFID };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDispositionHistory", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDispositionHistory", pars);
                //}
                _dt = _ds.Tables[0];
                return _ds;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// GetMyQueueSearch
        /// </summary>
        /// <param name="iUserId"></param>
        /// <param name="iIssueNumber"></param>
        /// <param name="iType"></param>
        /// <returns></returns>
        public DataTable GetMyQueueSearch(int iUserId, string iIssueNumber, int iType, int? iProductLine, int? iPartNumber, string dStartDate,
                                                string dEndDate, int iVSId, string vcQNNumber, string vcOtherPartNumber)
        {
            try
            {
                var Ipars = new SqlParameter[9];
                var Dpars = new SqlParameter[8];

                string sp = string.Empty;
                if (iType == 1)
                {
                    //pars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iUserId", Value = iUserId };
                    //pars[1] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iIssueNumber", Value = iIssueNumber };
                    Ipars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iUserId", Value = iUserId };
                    Ipars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueNumber", Value = iIssueNumber };
                    Ipars[2] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iProductLine", Value = iProductLine };
                    Ipars[3] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iPartNumber", Value = iPartNumber };
                    Ipars[4] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@dStartDate", Value = dStartDate };
                    Ipars[5] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@dEndDate", Value = dEndDate };
                    Ipars[6] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVSId", Value = iVSId };
                    Ipars[7] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@vcQNNumber", Value = vcQNNumber };
                    Ipars[8] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@vcOtherPartNumber", Value = vcOtherPartNumber };
                    sp = "usp_ISM_SearchByIssue_VS";//usp_ISM_SearchByIssue_test//usp_ISM_SearchByIssue//usp_ISM_SearchByIssue_VS
                    _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, sp, Ipars);
                }
                else
                {
                    Dpars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iUserId", Value = iUserId };
                    Dpars[1] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iIssueWFID", Value = iIssueNumber };
                    Dpars[2] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iProductLine", Value = iProductLine };
                    Dpars[3] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iPartNumber", Value = iPartNumber };
                    Dpars[4] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@dStartDate", Value = dStartDate };
                    Dpars[5] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@dEndDate", Value = dEndDate };
                    Dpars[6] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVSId", Value = iVSId };
                    Dpars[7] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@vcOtherPartNumber", Value = vcOtherPartNumber };
                    sp = "usp_ISM_SearchByDisposition_VS";
                    _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, sp, Dpars);
                }

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetRolesByUserId
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public DataTable GetRolesByUserId(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = iUserId
                };
                DataSet ds;
                DataTable dt;
                ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetRolesByUserId", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetRolesByUserId", pars);
                //}
                dt = ds.Tables[0];
                return dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// UpdateToSwitchRole
        /// </summary>
        /// <param name="iCurrentRole"></param>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public int UpdateToSwitchRole(int iCurrentRole, int iUserId)
        {
            try
            {
                var pars = new SqlParameter[3];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iCurrentRole",
                    Value = iCurrentRole
                };
                pars[1] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = iUserId
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };
                int result;
                int returnValue;

                result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_UpdateToSwitchRole", pars));
                returnValue = Convert.ToInt32(pars[2].Value);

                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateToSwitchRole", pars));
                //    returnValue = Convert.ToInt32(pars[2].Value);
                //}
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetDispositionType
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        public DataTable GetDispositionType(int iIssueWFID)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueWFID", Value = iIssueWFID };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDispositionType", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDispositionType", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetAssignedToEmail
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public DataTable GetAssignedToEmail(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iUserId", Value = iUserId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetAssignedToEmail", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetAssignedToEmail", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetDashboardTopCount
        /// </summary>
        /// <param name="iUserId"></param>
        /// <returns></returns>
        public DataTable GetDashboardTopCount(int iUserId,int? month)
        {
            try
            {
                var pars = new SqlParameter[2];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iUserId", Value = iUserId };
                pars[1] = month!=null? new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@month", Value = month }: new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@month", Value = DBNull.Value };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardTopCount", pars);

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetWorkflowTypes(int iVSid)
        {
            try
            {

                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSid", Value = iVSid };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetWorkflowsByVS", pars);
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iWorkFlowID, vcWorkFlowName from tbl_ISM_WorkFlow where bStatus=1");

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// GetWorkflow disposition Id
        /// </summary>
        /// <param name="iWorkFlowID"></param>
        /// <param name="iDispositionID"></param>
        /// <returns></returns>
        public DataTable GetWFDId(int iWorkFlowID, int iDispositionID)
        {
            try
            {
                var pars = new SqlParameter[2];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iWorkFlowID", Value = iWorkFlowID };

                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iDispositionID", Value = iDispositionID };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_Get_WFDId", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_Get_WFDId", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// UpdateIssueDisposition_InsertDtransaction
        /// </summary>
        /// <param name="req"></param>
        /// <param name="fileBytesList"></param>
        /// <returns></returns>
        public int UpdateIssueDisposition_InsertDtransaction(PIUpdateDispositionRecords req, List<byte[]> fileBytesList)/*, List<byte[]> fileBytesList*/
        {
            try
            {
                #region--ISM_Disposition Data Table
                //DataTable tbl_ISM_Disposition_Type_Data = new DataTable();
                //tbl_ISM_Disposition_Type_Data.Columns.Add("iIssueNumber");
                //tbl_ISM_Disposition_Type_Data.Columns.Add("iWorkFlowDispotionId");
                //tbl_ISM_Disposition_Type_Data.Columns.Add("iStatus");
                //tbl_ISM_Disposition_Type_Data.Columns.Add("iAssignedTo");
                //tbl_ISM_Disposition_Type_Data.Columns.Add("iAssignedGroup");
                //tbl_ISM_Disposition_Type_Data.Columns.Add("iActivityOwner");
                //tbl_ISM_Disposition_Type_Data.Columns.Add("iLastProcessedBy");
                //tbl_ISM_Disposition_Type_Data.Columns.Add("vcComments");

                //if (req.vbDocument != null)
                //{
                //    for (int i = 0; i < req.WFDId.Count(); i++)//iWorkFlowDispotionId
                //    {
                //        tbl_ISM_Disposition_Type_Data.Rows.Add(
                //                    req.iIssueNumber,
                //                    req.WFDId[i],//iWorkFlowDispotionId
                //                    0,
                //                    req.iAssignedTo[i],
                //                    req.iAssignedGroup[i],
                //                    0,
                //                    req.iLastProcessedUser,
                //                    req.vcComments[i]
                //            );
                //    }
                //}
                #endregion

                #region--ISM_Files Data Table
                DataTable tbl_ISM_Files_Type_Data = new DataTable();
                tbl_ISM_Files_Type_Data.Columns.Add("iInsId");
                tbl_ISM_Files_Type_Data.Columns.Add("vcFileName");
                tbl_ISM_Files_Type_Data.Columns.Add("isLastCopy");
                tbl_ISM_Files_Type_Data.Columns.Add("vbDocument", typeof(SqlBinary));
                tbl_ISM_Files_Type_Data.Columns.Add("iDocFlag");
                if (req.vbDocument != null)
                {
                    for (int i = 0; i < req.vbDocument.Count(); i++)
                    {
                        tbl_ISM_Files_Type_Data.Rows.Add(
                                    req.iIssueWFID,
                                   req.vcFileName[i],
                                   req.isLastCopy,
                                   fileBytesList[i],
                                   req.iDocFlag
                            );
                    }
                }
                #endregion

                #region--Email
                DataTable tbl_ISM_Disposition_CC_Email_Type_Data = new DataTable();
                tbl_ISM_Disposition_CC_Email_Type_Data.Columns.Add("iDispositionNumber");
                tbl_ISM_Disposition_CC_Email_Type_Data.Columns.Add("vcCCEmail");
                if (req.vcCCEmail.Count() != 0)
                {
                    for (int i = 0; i < req.vcCCEmail.Count(); i++)
                    {
                        tbl_ISM_Disposition_CC_Email_Type_Data.Rows.Add(
                                    req.iIssueWFID,
                                   req.vcCCEmail[i]
                            );
                    }
                }
                #endregion--Email
                var pars = new SqlParameter[10];

                #region
                //pars[0] = new SqlParameter();
                //pars[0].ParameterName = "@tbl_ISM_Disposition_Type_Data";
                //pars[0].Value = tbl_ISM_Disposition_Type_Data;

                pars[0] = new SqlParameter();
                pars[0].ParameterName = "@tbl_ISM_Files_Type_Data";
                pars[0].Value = tbl_ISM_Files_Type_Data;

                pars[1] = new SqlParameter();
                pars[1].ParameterName = "@tbl_ISM_Disposition_CC_Email_Type_Data";
                pars[1].Value = tbl_ISM_Disposition_CC_Email_Type_Data;
                #endregion

                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iAssignedTo",
                    Value = req.iAssignedTo
                };
                pars[3] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@iAssignedGroup",
                    Value = req.iAssignedGroup
                };
                pars[4] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iStatus",
                    Value = req.iStatus
                };
                pars[5] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@iLastProcessedBy",
                    Value = req.iLastProcessedBy
                };
                pars[6] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueWFID",
                    Value = req.iIssueWFID
                };
                pars[7] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iWorkFlowDisposition",
                    Value = req.iWorkFlowDisposition
                };
                pars[8] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@Comments",
                    Value = req.Comments
                };
                pars[9] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };
                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateIssueDisposition_InsertDtransaction", pars));
                    returnValue = Convert.ToInt32(pars[7].Value);

                    #region
                    //if (returnValue == 1)
                    //{
                    //string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                    //string subject = string.Empty;
                    //string toAddress = string.Empty;
                    //string toCC = string.Empty;
                    //var emailhelper = new EmailNotification();
                    //StringBuilder sb = new StringBuilder();
                    //sb.Append("<h2><center>ISM- Dashboard Tool: User updated the Request</center></h2>");
                    //sb.Append("<p>Hi " + req.T_iAssignGroupText + ",</p> ");
                    //sb.Append("<p>User has updated the request with below details");
                    //sb.Append("<html><head><style> table, th, td {border: 1px solid black;}</style></head><body>");
                    //sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='5'><center><h4>Issue Details</h4></center></td></tr>");
                    //sb.Append("<tr><th style='text-align:left'>Issue Number</th><td colspan='4'>" + "ISS-" + req.iIssueNumber + "</ td ></ tr > ");
                    //sb.Append("<tr><th style='text-align:left'>Productline</th><td colspan='4'>" + req.vcProductName + "</ td ></ tr > ");
                    //sb.Append("<tr><th style='text-align:left'>PartNumber</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");
                    //sb.Append("<tr><th style='text-align:left'>Category</th><td colspan='4'>" + req.vcCategoryName + "</ td ></ tr > ");
                    //sb.Append("<tr><th style='text-align:left'>Assigned Group</th><td colspan='4'>" + req.T_iAssignGroupText + "</ td ></ tr > ");
                    //sb.Append("<tr><th style='text-align:left'>Assigned To</th><td colspan='4'>" + req.T_iAssignToText + "</ td ></ tr > ");
                    //sb.Append("<tr><th style='text-align:left'>Issue Description</th><td colspan='4'>" + req.T_vcCommentsText + "</ td ></ tr > ");
                    //sb.Append("</table></body></html>");
                    //sb.Append("<br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                    //sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                    //subject = "User has updated the request- ISS-" + req.iIssueNumber + " for " + req.vcProductName;
                    //toAddress = req.toMail;
                    //toCC = string.Join(",", req.vcCCEmail);
                    //emailhelper.SendMailToAdmin(toreply, toAddress, toCC.Trim(), subject, sb.ToString(), true);
                    //}
                    #endregion
                }
                return returnValue;
            }


            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdateDispositionWFRequest(PIUpdateDispositionRecords req, List<byte[]> fileBytesList)
        {
            try
            {
                #region--ISM_Files Data Table
                DataTable tbl_ISM_Files_Type_Data = new DataTable();
                tbl_ISM_Files_Type_Data.Columns.Add("iInsId");
                tbl_ISM_Files_Type_Data.Columns.Add("vcFileName");
                tbl_ISM_Files_Type_Data.Columns.Add("isLastCopy");
                tbl_ISM_Files_Type_Data.Columns.Add("vbDocument", typeof(SqlBinary));
                tbl_ISM_Files_Type_Data.Columns.Add("iDocFlag");
                if (req.vbDocument != null)
                {
                    for (int i = 0; i < req.vbDocument.Count(); i++)
                    {
                        tbl_ISM_Files_Type_Data.Rows.Add(
                                    req.iIssueWFID,
                                   req.vcFileName[i],
                                   req.isLastCopy,
                                   fileBytesList[i],
                                   req.iDocFlag
                            );
                    }
                }
                #endregion

                #region--Email
                DataTable tbl_ISM_Disposition_CC_Email_Type_Data = new DataTable();
                tbl_ISM_Disposition_CC_Email_Type_Data.Columns.Add("iDispositionNumber");
                tbl_ISM_Disposition_CC_Email_Type_Data.Columns.Add("vcCCEmail");
                if (req.vcCCEmail.Count() != 0)
                {
                    for (int i = 0; i < req.vcCCEmail.Count(); i++)
                    {
                        tbl_ISM_Disposition_CC_Email_Type_Data.Rows.Add(
                                    req.iIssueWFID,
                                   req.vcCCEmail[i]
                            );
                    }
                }
                #endregion--Email
                var pars = new SqlParameter[16];

                #region
                pars[0] = new SqlParameter();
                pars[0].ParameterName = "@tbl_ISM_Files_Type_Data";
                pars[0].Value = tbl_ISM_Files_Type_Data;

                pars[1] = new SqlParameter();
                pars[1].ParameterName = "@tbl_ISM_Disposition_CC_Email_Type_Data";
                pars[1].Value = tbl_ISM_Disposition_CC_Email_Type_Data;
                #endregion

                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueWFID",
                    Value = req.iIssueWFID
                };

                pars[3] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@Comments",
                    Value = req.Comments
                };
                if (req.iStatus == 3 || req.iStatus == 4 || req.iStatus == 6 || req.iStatus == 0)
                {
                    pars[4] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.Int,
                        ParameterName = "@iAssignedGroup",
                        Value = DBNull.Value
                    };
                    pars[5] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.Int,
                        ParameterName = "@iAssignedTo",
                        Value = DBNull.Value
                    };
                }
                else
                {
                    pars[4] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.Int,
                        ParameterName = "@iAssignedGroup",
                        Value = req.iAssignedGroup
                    };
                    pars[5] = new SqlParameter
                    {
                        SqlDbType = SqlDbType.Int,
                        ParameterName = "@iAssignedTo",
                        Value = req.iAssignedTo
                    };
                }

                pars[6] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iStatus",
                    Value = req.iStatus
                };
                pars[7] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iProcessedBy",
                    Value = req.iProcessedBy
                };
                //@iUserId
                pars[8] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = req.iUserId
                };
                pars[9] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcSolutionForClosed",
                    Value = req.vcSolutionForClosed
                };
                pars[10] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_One",
                    Value = req.vcCRCO_One
                };
                pars[11] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_Two",
                    Value = req.vcCRCO_Two
                };
                pars[12] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_Three",
                    Value = req.vcCRCO_Three
                };
                pars[13] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_Four",
                    Value = req.vcCRCO_Four
                };
                pars[14] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCRCO_Five",
                    Value = req.vcCRCO_Five
                };
                pars[15] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };
                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateDispositionWFRequest", pars));
                    returnValue = Convert.ToInt32(pars[15].Value);


                    DataSet statusDs = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select I.iStatus,U.vcGivenname from tbl_ISM_Issue I inner join tbl_ISM_User U on U.iUserId=I.iActivityOwner where I.iIssueNumber=" + req.iIssueNumber);
                    DataTable statusDt = statusDs.Tables[0];
                    List<string> ls = req.vcCCEmail.ToList();
                    if (Convert.ToInt32(statusDt.Rows[0]["iStatus"]) == 4 || Convert.ToInt32(statusDt.Rows[0]["iStatus"]) == 6)
                    {
                        string itoreply = ConfigurationManager.AppSettings["ReplyToMail"];
                        string isubject = string.Empty;
                        string itoAddress = string.Empty;
                        string itoCC = string.Empty;
                        var iemailhelper = new EmailNotification();

                        ls.Add(req.Initiator);
                        req.vcCCEmail = ls.ToArray();
                        // req.DisplayDispositionId.Substring(0, req.DisplayDispositionId.Length-3);
                        StringBuilder sbi = new StringBuilder();
                        sbi.Append("<h2><center>ISM- Dashboard Tool: Issue Updated</center></h2>");
                        sbi.Append("<p>Hi " + statusDt.Rows[0]["vcGivenname"] + "</p> ");
                        sbi.Append("<p>User has updated the request with below details");
                        sbi.Append("<html><head><style> th, td {border: 1px solid black;}</style></head><body>");
                        sbi.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='5'><center><h4>Issue Details</h4></center></td></tr>");
                        sbi.Append("<tr><th style='text-align:left'>Issue Number</th><td colspan='4'>" + req.DisplayDispositionId.Substring(0, req.DisplayDispositionId.Length - 3) + "</ td ></ tr > ");
                        sbi.Append("<tr><th style='text-align:left'>Part Number</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");

                        sbi.Append("<tr><th style='text-align:left'>Issue Status</th><td colspan='4'>" + req.iStatusText + "</ td ></ tr > ");
                        sbi.Append("</table></body></html>");
                        //sb.Append("<tr><th style='text-align:left'>Issue Description</th><td colspan='4'>" + req.Comments + "</ td ></ tr > ");

                        //sbi.Append("<br /><b>Engineering Justification Write-up: </b>" + req.EJWU);

                        //sbi.Append("<br /><br /><b>Last comments: </b>" + req.Comments + "<br />");
                        sbi.Append("<br /><br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                        sbi.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                        //subject = "Disposition updated- " + req.DisplayIssueNumber;
                        isubject = "Issue updated- " + req.DisplayDispositionId.Substring(0, req.DisplayDispositionId.Length - 3) + " for " + req.vcPartNumberName;

                        itoAddress = req.Initiator;
                        //itoCC = string.Join(",", req.vcCCEmail);
                        iemailhelper.SendMailToAdmin(itoreply, itoAddress, "", isubject, sbi.ToString(), true);

                    }
                    string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                    string subject = string.Empty;
                    string toAddress = string.Empty;
                    string toCC = string.Empty;
                    var emailhelper = new EmailNotification();
                    DataSet dispositionNumberDs = GetDispositionDetails(Convert.ToInt32(req.iIssueNumber));

                    //var parsIWFIdRef = new SqlParameter[1];
                    //parsIWFIdRef[0] = new SqlParameter
                    //{
                    //    SqlDbType = SqlDbType.VarChar,
                    //    ParameterName = "@iIssueWFID",
                    //    Value = req.iIssueWFID
                    //};
                    //_ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDispositionWFIDSingle", parsIWFIdRef);


                    #region--EmailConfig
                    if (returnValue == 1)
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.Append("<h2><center>ISM- Dashboard Tool: Disposition updated</center></h2>");
                        if (req.iStatus == 2)
                            sb.Append("<p>Hi " + req.iAssignedToText + ",</p> ");
                        else
                            sb.Append("<p>Hi</p> ");
                        sb.Append("<p>User has updated the request with below details");
                        sb.Append("<html><head><style> th, td {border: 1px solid black;}</style></head><body>");
                        sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='5'><center><h4>Issue Details</h4></center></td></tr>");
                        sb.Append("<tr><th style='text-align:left'>Disposition Number</th><td colspan='4'>" + req.DisplayDispositionId + "</ td ></ tr > ");
                        sb.Append("<tr><th style='text-align:left'>Part Number</th><td colspan='4'>" + req.vcPartNumberName + "</ td ></ tr > ");


                        if (req.iStatus == 2)
                        {
                            sb.Append("<tr><th style='text-align:left'>Assigned Group</th><td colspan='4'>" + req.iAssignedGroupText + "</ td ></ tr > ");
                            sb.Append("<tr><th style='text-align:left'>Assigned To</th><td colspan='4'>" + req.iAssignedToText + "</ td ></ tr > ");
                        }
                        sb.Append("<tr><th style='text-align:left'>Disposition Status</th><td colspan='4'>" + req.iStatusText + "</ td ></ tr > ");
                        sb.Append("</table></body></html>");
                        //sb.Append("<tr><th style='text-align:left'>Issue Description</th><td colspan='4'>" + req.Comments + "</ td ></ tr > ");

                        sb.Append("<br /><b>Engineering Justification Write-up: </b>" + req.EJWU);

                        sb.Append("<br /><br /><b>Last comments: </b>" + req.Comments + "<br />");
                        sb.Append("<br /><br />Please click the link to open the ISM Dashboard Tool :<a href='" + URLDashboard + "'>click here</a>");
                        sb.Append("<p>Regards, <br/>ISM Dashboard Tool Team.</p>");
                        //subject = "Disposition updated- " + req.DisplayIssueNumber;
                        subject = "Disposition updated- " + req.DisplayDispositionId + " for " + req.vcPartNumberName;

                        toAddress = req.toMail;
                        toCC = string.Join(",", req.vcCCEmail);
                        emailhelper.SendMailToAdmin(toreply, toAddress, toCC.Trim(), subject, sb.ToString(), true);
                    }
                    #endregion
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// GetCCEmails
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        public DataTable GetCCEmails(int iIssueNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueNumber", Value = iIssueNumber };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetCCMailsByIssue", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetCCMailsByIssue", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// GetDispositionCCMailsByIssue
        /// </summary>
        /// <param name="iIssueNumber"></param>
        /// <returns></returns>
        public DataTable GetDispositionCCMailsByIssue(int iDispositionNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iDispositionNumber", Value = iDispositionNumber };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDispositionCCMailsByIssue", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDispositionCCMailsByIssue", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetExistingDispositionsByIssueNumber(int iIssueNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueNumber", Value = iIssueNumber };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetExistingDispositionsByIssueNumber", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetExistingDispositionsByIssueNumber", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="iWorkFlowID"></param>
        /// <returns></returns>
        public DataTable GetWorkflowType(int iIssueNumber)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iWorkFlowName from tbl_ISM_Issue where iIssueNumber=" + iIssueNumber);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select iWorkFlowName from tbl_ISM_Issue where iIssueNumber=" + iIssueNumber);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetUploadedDocsForDisposition(int iIssueNumber, int iIssueWFID)
        {
            try
            {
                var pars = new SqlParameter[2];

                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueNumber",
                    Value = iIssueNumber
                };
                pars[1] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueWFID",
                    Value = iIssueWFID
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetUploadedDocsForDisposition", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetUploadedDocsForDisposition", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetIssueNumberByWFID(int iIssueWFID)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueWFID",
                    Value = iIssueWFID
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetIssueNumberByWFID", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetIssueNumberByWFID", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetWorkflowDetails(int iIssueWFID)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueWFID",
                    Value = iIssueWFID
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetWorkflowDetails", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetWorkflowDetails", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetMyQueueDisposition(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iUserId", Value = iUserId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetMyQueueDisposition", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetMyQueueDisposition", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetProductLineForPCN(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVsId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetPlatformByVS", pars);

                //select PL.iProductLineID,PL.vcProductName,C.vcCategoryName from tbl_ISM_ProductLine PL inner join tbl_ISM_Category C on PL.iCategoryID=C.iCategoryID where  PL.bIsActive=1

                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select PL.iProductLineID,PL.vcProductName,C.vcCategoryName from tbl_ISM_ProductLine PL inner join tbl_ISM_Category C on PL.iCategoryID=C.iCategoryID where  PL.bIsActive=1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetCategoryNameByPL(int iProductLineID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select PL.iProductLineID,PL.vcProductName,C.vcCategoryName from tbl_ISM_ProductLine PL inner join tbl_ISM_Category C on PL.iCategoryID=C.iCategoryID where PL.iProductLineID=" + iProductLineID + " and PL.bIsActive=1");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select PL.iProductLineID,PL.vcProductName,PL.iCategoryID,C.vcCategoryName from tbl_ISM_ProductLine PL inner join tbl_ISM_Category C on PL.iCategoryID=C.iCategoryID where PL.iProductLineID=" + iProductLineID + " and PL.bIsActive=1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //GetPartNumberPCN
        public DataTable GetPartNumberPCN(int iProductline, int iVSId)
        {
            try
            {

                var pars = new SqlParameter[2];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iProductLineID", Value = iProductline };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVsId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetPartNumberBasedonPlatform", pars);

                //usp_ISM_GetPartNumberBasedonPlatform,usp_ISM_GetPartNumbersByPlatForm
                //select iPartNumberID,vcPartNumberName,vcPartNumber,vcPartDescription from tbl_ISM_PartNumber where iProductLineID = " + iProductline + " and bIsActive = 1


                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select iPartNumberID,vcPartNumberName,vcPartNumber,vcPartDescription from tbl_ISM_PartNumber where iProductLineID = " + iProductline + " and bIsActive = 1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetPartDescription(int iPartNumberID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select vcPartDescription from tbl_ISM_PartNumber where iPartNumberID = " + iPartNumberID + " and bIsActive = 1");

                //var pars = new SqlParameter[2];
                //pars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iProductLineID", Value = iProductline };
                //pars[1] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVsId", Value = iVSId };
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetPartNumberBasedonPlatform", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetDispositionStatusByIssueNumber(int iIssueNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueNumber",
                    Value = iIssueNumber
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDispositionStatusByIssueNumber", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDispositionStatusByIssueNumber", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetIssueStatusByIssueNumber(int iIssueNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iIssueNumber",
                    Value = iIssueNumber
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetIssueStatusByIssueNumber", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetIssueStatusByIssueNumber", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetUserNameByUserId()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iUserId,vcGivenname from tbl_ISM_User where iStatus=1");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select iUserId,vcGivenname from tbl_ISM_User where iStatus=1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #region--Lov
        public DataTable GetLOVWorkFlow()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select WF.iWorkFlowID, WF.vcWorkFlowName,WF.dCreatedDate,U.vcFirstName,WF.bStatus from tbl_ISM_WorkFlow WF left join tbl_ISM_User U on U.iUserId = WF.iCreatedBy");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select WF.iWorkFlowID, WF.vcWorkFlowName,WF.dCreatedDate,U.vcFirstName,WF.bStatus from tbl_ISM_WorkFlow WF left join tbl_ISM_User U on U.iUserId = WF.iCreatedBy");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetLOVDisposition()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select DT.iDispositionTypeID,DT.vcDispositionName,DT.dCreatedDate,U.vcFirstName,DT.bStatus from tbl_ISM_DipositionType DT left join tbl_ISM_User U on U.iUserId = DT.iCreatedBy ");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select DT.iDispositionTypeID,DT.vcDispositionName,DT.dCreatedDate,U.vcFirstName,DT.bStatus from tbl_ISM_DipositionType DT left join tbl_ISM_User U on U.iUserId = DT.iCreatedBy ");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetLOVCategory()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select CT.iCategoryID,CT.vcCategoryName,CT.dCreatedDate,U.vcFirstName,CT.bIsActive from tbl_ISM_Category CT left join tbl_ISM_User U on U.iUserId = CT.iCreatedBy");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select CT.iCategoryID,CT.vcCategoryName,CT.dCreatedDate,U.vcFirstName,CT.bIsActive from tbl_ISM_Category CT left join tbl_ISM_User U on U.iUserId = CT.iCreatedBy");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetLOVProductSample(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetAllProduct", pars);
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select PL.iProductLineID,PL.vcProductName,PL.dCreatedDate,U.vcFirstName,PL.bIsActive from tbl_ISM_ProductLine PL left join tbl_ISM_User U on U.iUserId = PL.iCreatedBy");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetLOVPrioritySample(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetPriority", pars);

                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select PT.iPriorityID,PT.vcPriorityName,PT.dCreatedDate,U.vcFirstName,PT.bIsActive from tbl_ISM_Priority PT left join tbl_ISM_User U on U.iUserId = PT.iCreatedBy");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetLOVPartNumberSample(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetAllPartNumbers_VS", pars);
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select PN.iPartNumberID,PN.vcPartNumberName,PN.dCreatedDate,U.vcFirstName,PN.bIsActive from tbl_ISM_PartNumber PN left join tbl_ISM_User U on U.iUserId = PN.iCreatedBy");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetLOVStatus()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select S.iStatusID,S.vcStatusDescription,S.dCreatedDate,U.vcFirstName,S.bIsActive from tbl_ISM_Status s left join tbl_ISM_User U on U.iUserId = S.iCreatedBy");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select S.iStatusID,S.vcStatusDescription,S.dCreatedDate,U.vcFirstName,S.bIsActive from tbl_ISM_Status s left join tbl_ISM_User U on U.iUserId = S.iCreatedBy");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #region WorkFlow

        public DataTable GetLOVWorkFlow(int iWorkFlowID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select WF.iWorkFlowID, WF.vcWorkFlowName,WF.dCreatedDate,U.vcFirstName,WF.bStatus from tbl_ISM_WorkFlow WF left join tbl_ISM_User U on U.iUserId = WF.iCreatedBy where iWorkFlowID=" + iWorkFlowID);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select WF.iWorkFlowID, WF.vcWorkFlowName,WF.dCreatedDate,U.vcFirstName,WF.bStatus from tbl_ISM_WorkFlow WF left join tbl_ISM_User U on U.iUserId = WF.iCreatedBy where iWorkFlowID=" + iWorkFlowID);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdateWorkFlowDet(WFObj upWfreq)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iWorkFlowID",
                    Value = upWfreq.iWorkFlowID
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcWorkFlowName",
                    Value = upWfreq.vcWorkFlowName
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bStatus",
                    Value = upWfreq.bStatus
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateWFRequest", pars));
                    returnValue = Convert.ToInt32(pars[3].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable ValidateWorkFlowDet(WFObj req)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select WF.iWorkFlowID, WF.vcWorkFlowName from tbl_ISM_WorkFlow WF where vcWorkFlowName=" + "'" + req.vcWorkFlowName + "'");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select WF.iWorkFlowID, WF.vcWorkFlowName from tbl_ISM_WorkFlow WF where vcWorkFlowName=" + "'" + req.vcWorkFlowName + "'");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int InsertWorkFlowDet(WFObj upWfreq)
        {
            try
            {
                var pars = new SqlParameter[3];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcWorkFlowName",
                    Value = upWfreq.vcWorkFlowName
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = upWfreq.iUserId
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertWFRequest", pars));
                    returnValue = Convert.ToInt32(pars[2].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Disposition

        public DataTable GetLOVDsiposition(int iDispositionTypeID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select DT.iDispositionTypeID, DT.vcDispositionName,DT.dCreatedDate,U.vcFirstName,DT.bStatus from tbl_ISM_DipositionType DT left join tbl_ISM_User U on U.iUserId = DT.iCreatedBy=" + iDispositionTypeID);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select DT.iDispositionTypeID, DT.vcDispositionName,DT.dCreatedDate,U.vcFirstName,DT.bStatus from tbl_ISM_DipositionType DT left join tbl_ISM_User U on U.iUserId = DT.iCreatedBy=" + iDispositionTypeID);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdateDispositionDet(DPObj upWfreq)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iDispositionTypeID",
                    Value = upWfreq.iDispositionTypeID
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcDispositionName",
                    Value = upWfreq.vcDispositionName
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bStatus",
                    Value = upWfreq.bStatus
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateDispositionRequest", pars));
                    returnValue = Convert.ToInt32(pars[3].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable ValidateDispositionDet(DPObj req)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select DT.iDispositionTypeID, DT.vcDispositionName from tbl_ISM_DipositionType DT where DT.vcDispositionName= " + "'" + req.vcDispositionName + "'");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select DT.iDispositionTypeID, DT.vcDispositionName from tbl_ISM_DipositionType DT where DT.vcDispositionName= " + "'" + req.vcDispositionName + "'");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int InsertDispositionDet(DPObj upDPreq)
        {
            try
            {
                var pars = new SqlParameter[3];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcDispositionName",
                    Value = upDPreq.vcDispositionName
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = upDPreq.iUserId
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertDispositionRequest", pars));
                    returnValue = Convert.ToInt32(pars[2].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Category

        public DataTable GetLOVCategory(int iCategoryID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select C.iCategoryID, C.vcCategoryName,C.dCreatedDate,U.vcFirstName,C.bIsActive from tbl_ISM_Category C left join tbl_ISM_User U on U.iUserId = C.iCreatedBy where C.iCategoryID=" + iCategoryID);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select C.iCategoryID, C.vcCategoryName,C.dCreatedDate,U.vcFirstName,C.bIsActive from tbl_ISM_Category C left join tbl_ISM_User U on U.iUserId = C.iCreatedBy where C.iCategoryID=" + iCategoryID);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetLOVALLCategory()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iCategoryID,vcCategoryName from tbl_ISM_Category where bIsActive=1");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select iCategoryID,vcCategoryName from tbl_ISM_Category where bIsActive=1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }


        public int UpdateCategoryDet(CObj Ctreq)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iCategoryID",
                    Value = Ctreq.iCategoryID
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCategoryName",
                    Value = Ctreq.vcCategoryName
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bIsActive",
                    Value = Ctreq.bIsActive
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateCategoryRequest", pars));
                    returnValue = Convert.ToInt32(pars[3].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable ValidateCategoryDet(CObj req)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select C.iCategoryID, C.vcCategoryName from tbl_ISM_Category C  where vcCategoryName=" + "'" + req.vcCategoryName + "'");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int InsertCategoryDet(CObj ctreq)
        {
            try
            {
                var pars = new SqlParameter[3];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcCategoryName",
                    Value = ctreq.vcCategoryName
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = ctreq.iUserId
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertCategoryRequest", pars));
                    returnValue = Convert.ToInt32(pars[2].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Product

        public DataTable GetLOVProduct(int iProductLineID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select PL.iProductLineID, PL.vcProductName,PL.dCreatedDate,U.vcFirstName,PL.bIsActive from tbl_ISM_ProductLine PL left join tbl_ISM_User U on U.iUserId = PL.iCreatedBy where PL.iProductLineID=" + iProductLineID);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select PL.iProductLineID, PL.vcProductName,PL.dCreatedDate,U.vcFirstName,PL.bIsActive from tbl_ISM_ProductLine PL left join tbl_ISM_User U on U.iUserId = PL.iCreatedBy where PL.iProductLineID=" + iProductLineID);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdateProductDet(PRDObj prdreq)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iProductLineID",
                    Value = prdreq.iProductLineID
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcProductName",
                    Value = prdreq.vcProductName
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bIsActive",
                    Value = prdreq.bIsActive
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateProductRequest", pars));
                    returnValue = Convert.ToInt32(pars[3].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable ValidateProductDet(PRDObj prdreq)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text,
                    "Select PL.iProductLineID, PL.vcProductName from tbl_ISM_ProductLine PL inner join tbl_ISM_ProductLine_VS PLVS on PLVS.iProductLineId = PL.iProductLineID where vcProductName =" + "'" + prdreq.vcProductName + "'" + " and PLVS.iVsId =" + prdreq.iVSId);
                
                   // "Select PL.iProductLineID, PL.vcProductName from tbl_ISM_ProductLine PL where vcProductName=" + "'" + prdreq.vcProductName + "'");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select PL.iProductLineID, PL.vcProductName from tbl_ISM_ProductLine PL where vcProductName=" + "'" + prdreq.vcProductName + "'");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int InsertProductDet(PRDObj prdreq)
        {
            try
            {
                var pars = new SqlParameter[5];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcProductName",
                    Value = prdreq.vcProductName
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = prdreq.iUserId
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iCategoryID",
                    Value = prdreq.iCategoryID
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVsId",
                    Value = prdreq.iVSId
                };
                pars[4] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    //result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertProductRequest", pars));
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertProductRequest_InsertVS", pars));//Mathu
                    returnValue = Convert.ToInt32(pars[4].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Priority

        public DataTable GetLOVPriority(int iPriorityID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select PR.iPriorityID, PR.vcPriorityName,PR.dCreatedDate,U.vcFirstName,PR.bIsActive from tbl_ISM_Priority PR left join tbl_ISM_User U on U.iUserId = PR.iCreatedBy where PR.iPriorityID= " + iPriorityID);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select PR.iPriorityID, PR.vcPriorityName,PR.dCreatedDate,U.vcFirstName,PR.bIsActive from tbl_ISM_Priority PR left join tbl_ISM_User U on U.iUserId = PR.iCreatedBy where PR.iPriorityID= " + iPriorityID);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdatePriorityDet(PRIObj prtreq)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iPriorityID",
                    Value = prtreq.iPriorityID
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcPriorityName",
                    Value = prtreq.vcPriorityName
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bIsActive",
                    Value = prtreq.bIsActive
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdatePriorityRequest", pars));
                    returnValue = Convert.ToInt32(pars[3].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable ValidatePriorityDet(PRIObj prtreq)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text,
                    "Select PR.iPriorityID, PR.vcPriorityName from tbl_ISM_Priority PR inner join tbl_ISM_Priority_VS PVS on PVS.iPriorityId =PR.iPriorityID where vcPriorityName =" + "'" + prtreq.vcPriorityName + "'" + " and PVS.iVSid =" + prtreq.iVSId);


                    //"Select PR.iPriorityID, PR.vcPriorityName from tbl_ISM_Priority PR where vcPriorityName=" + "'" + prtreq.vcPriorityName + "'");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select PR.iPriorityID, PR.vcPriorityName from tbl_ISM_Priority PR where vcPriorityName=" + "'" + prtreq.vcPriorityName + "'");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int InsertPriorityDet(PRIObj prtreq)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcPriorityName",
                    Value = prtreq.vcPriorityName
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = prtreq.iUserId
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVSId",
                    Value = prtreq.iVSId
                };//MATHU
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;

                //result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_InsertPriorityRequest", pars));
                result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_InsertPriorityRequest_InsertVS", pars));//Mathu
                returnValue = Convert.ToInt32(pars[3].Value);

                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region PartNumber

        public DataTable GetLOVPartNumber(int iPartNumberID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select PN.iPartNumberID, PN.vcPartNumber,PN.dCreatedDate,U.vcFirstName,PN.bIsActive from tbl_ISM_PartNumber PN left join tbl_ISM_User U on U.iUserId = PN.iCreatedBy where PN.iPartNumberID= " + iPartNumberID);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select PN.iPartNumberID, PN.vcPartNumberName,PN.dCreatedDate,U.vcFirstName,PN.bIsActive from tbl_ISM_PartNumber PN left join tbl_ISM_User U on U.iUserId = PN.iCreatedBy where PN.iPartNumberID= " + iPartNumberID);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdatePartNumberDet(PNObj pnreq)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iPartNumberID",
                    Value = pnreq.iPartNumberID
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcPartNumber",
                    Value = pnreq.vcPartNumber
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bIsActive",
                    Value = pnreq.bIsActive
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_UpdatePartNumberRequest", pars));
                returnValue = Convert.ToInt32(pars[3].Value);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdatePartNumberRequest", pars));
                //    returnValue = Convert.ToInt32(pars[3].Value);
                //}
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable ValidatePartNumberDet(PNObj pnreq)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select PN.iPartNumberID, PN.vcPartNumberName from tbl_ISM_PartNumber PN where PN.vcPartNumberName= " + "'" + pnreq.vcPartNumberName + "'");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int InsertPartNumberDet(PNObj pnreq)
        {
            try
            {
                var pars = new SqlParameter[5];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcPartNumberName",
                    Value = pnreq.vcPartNumberName
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = pnreq.iUserId
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcPartDescription",
                    Value = pnreq.vcPartDescription
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iProductLineID",
                    Value = pnreq.iProductline
                };
                pars[4] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    //result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertPartNumberRequest", pars));
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertPartNumberRequest_InsertVS", pars));//Mathu
                    returnValue = Convert.ToInt32(pars[4].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Status

        public DataTable GetLOVStatus(int iStatusID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select S.iStatusID,S.vcStatusDescription,S.dCreatedDate,U.vcFirstName,S.dIsActive from tbl_ISM_Status S left join tbl_ISM_User U on U.iUserId = S.iCreatedBy where S.iStatusID= " + iStatusID);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select S.iStatusID,S.vcStatusDescription,S.dCreatedDate,U.vcFirstName,S.dIsActive from tbl_ISM_Status S left join tbl_ISM_User U on U.iUserId = S.iCreatedBy where S.iStatusID= " + iStatusID);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdateStatusDet(SObj sreq)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iStatusID",
                    Value = sreq.iStatusID
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcStatusDescription",
                    Value = sreq.vcStatusDescription
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bIsActive",
                    Value = sreq.bIsActive
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateStatusRequest", pars));
                    returnValue = Convert.ToInt32(pars[3].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable ValidateStatusDet(SObj sreq)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "Select S.iStatusID,S.vcStatusDescription from tbl_ISM_Status S where S.vcStatusDescription= " + "'" + sreq.vcStatusDescription + "'");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select S.iStatusID,S.vcStatusDescription from tbl_ISM_Status S where S.vcStatusDescription= " + "'" + sreq.vcStatusDescription + "'");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int InsertStatusDet(SObj sreq)
        {
            try
            {
                var pars = new SqlParameter[3];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcStatusDescription",
                    Value = sreq.vcStatusDescription
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = sreq.iUserId
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertStatusRequest", pars));
                    returnValue = Convert.ToInt32(pars[2].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion

        #region Group
        public int InsertGroups(GroupObj req)
        {
            try
            {
                var pars = new SqlParameter[5];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcGroupDescription",
                    Value = req.vcGroupDescription
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bStatus",
                    Value = req.bStatus
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iCreatedBy",
                    Value = req.iCreatedBy
                };

                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVSId",
                    Value = req.iVSId
                };//Mathu
                //pars[4] = new SqlParameter()
                //{
                //    SqlDbType = SqlDbType.Int,
                //    ParameterName = "@iSBUId",
                //    Value = req.iSBUId
                //};//Mathu
                pars[4] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };
                int result;
                int returnValue;
                //result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_InsertGroups", pars));
                result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_InsertGroups_InsertVS", pars));//Mathu
                returnValue = Convert.ToInt32(pars[4].Value);
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetLOVGroup(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetAllGroups", pars);
                //_ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iGroupID,vcGroupDescription,bStatus from tbl_ISM_Groups");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdateGroupEdit(int iGroupID, string vcGroupDescription, int bStatus)
        {
            try
            {
                var pars = new SqlParameter[4];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcGroupDescription",
                    Value = vcGroupDescription
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iGroupID",
                    Value = iGroupID
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bStatus",
                    Value = bStatus
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateGroupByGroupId", pars));
                    returnValue = Convert.ToInt32(pars[3].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetGroupRecordByGroupId(int iGroupID)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iGroupID, vcGroupDescription,bStatus from tbl_ISM_Groups where iGroupID =" + iGroupID);

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int CheckCurrentGroupStatus(int iAssignedGroupTo)
        {
            try
            {
                var pars = new SqlParameter[2];
                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@iAssignedGroupTo",
                    Value = iAssignedGroupTo
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_CheckCurrentGroupStatus", pars));
                    returnValue = Convert.ToInt32(pars[1].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region User Groups
        public DataTable GetUserGroups()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetUserGroups");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetUserGroups");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetUserGroupById(int iUserGroupID)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserGroupID",
                    Value = iUserGroupID
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_ManageUserGroupEdit", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_ManageUserGroupEdit", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int InsertUserGroup(int iUserID, int iGroupID, int iStatus, int iCreatedBy, int iVSId)
        {
            try
            {
                var pars = new SqlParameter[6];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserID",
                    Value = iUserID
                };
                pars[1] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iGroupID",
                    Value = iGroupID
                };
                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iStatus",
                    Value = iStatus
                };
                pars[3] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iCreatedBy",
                    Value = iCreatedBy
                };
                pars[4] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVSId",
                    Value = iVSId
                };//Mathu
                pars[5] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    //result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertUserGroup", pars));
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertUserGroup", pars));//Mathu
                    returnValue = Convert.ToInt32(pars[5].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdateUserGroup(int iUserGroupID, int iUserID, int iStatus, int iUpdatedBy, int iGroupID, int isAdmin)
        {
            try
            {
                var pars = new SqlParameter[7];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserGroupID",
                    Value = iUserGroupID
                };
                pars[1] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserID",
                    Value = iUserID
                };
                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUpdatedBy",
                    Value = iUpdatedBy
                };
                pars[3] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iStatus",
                    Value = iStatus
                };
                pars[4] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iGroupID",
                    Value = iGroupID
                };
                //isAdmin
                pars[5] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@isAdmin",
                    Value = isAdmin
                };
                pars[6] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateUserGroup", pars));
                    returnValue = Convert.ToInt32(pars[6].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region UserAccess
        public DataTable GetRequestedUsers(int iVSId)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select U.iUserId,U.vcGivenname,U.iStatus,U.vcEmail,UG.iGroupID from tbl_ISM_User U inner join tbl_ISM_UserGroups UG on U.iUserId = UG.iUserID where U.iStatus = 0 and UG.iVSId=" + iVSId);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    //_ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select iUserId,vcGivenname,iStatus,vcEmail from tbl_ISM_User where iStatus=0");
                //    //select U.iUserId,U.vcGivenname,U.iStatus,U.vcEmail,UG.iGroupID from tbl_ISM_User U inner join tbl_ISM_UserGroups UG on U.iUserId = UG.iUserID where U.iStatus = 0
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select U.iUserId,U.vcGivenname,U.iStatus,U.vcEmail,UG.iGroupID from tbl_ISM_User U inner join tbl_ISM_UserGroups UG on U.iUserId = UG.iUserID where U.iStatus = 0");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public int UpdateUsersAccess(int iUserId, int iUpdatedBy, int iGroupId, int isAdmin, int iVSId,int iRejectStatus)
        {
            try
            {
                var pars = new SqlParameter[7];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = iUserId
                };
                //pars[1] = new SqlParameter()
                //{
                //    SqlDbType = SqlDbType.Int,
                //    ParameterName = "@iStatus",
                //    Value = iStatus
                //};
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUpdatedBy",
                    Value = iUpdatedBy
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iGroupId",
                    Value = iGroupId
                };

                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@isAdmin",
                    Value = isAdmin
                };
                pars[4] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVSId",
                    Value = iVSId
                };
                pars[5] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iRejectStatus",
                    Value = iRejectStatus
                };
                pars[6] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_UpdateUsersAccess", pars));
                    returnValue = Convert.ToInt32(pars[6].Value);
                }
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //select iUserId,vcGivenname,iStatus,vcEmail from tbl_ISM_User where iUserId=

        public DataTable GetSelectedRequestUser(int iUserId)
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iUserId,vcGivenname,iStatus,vcEmail from tbl_ISM_User where iUserId=" + iUserId);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select iUserId,vcGivenname,iStatus,vcEmail from tbl_ISM_User where iUserId=" + iUserId);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetGivenNameByEmailId(string emailId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@vcEmail", Value = emailId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetGivenNameByEmailId", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetGivenNameByEmailId", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion
        #endregion

        #region--GetDispositionDetails
        public DataSet GetDispositionDetails(int iIssueNumber)
        {
            try
            {
                var parsIWFId = new SqlParameter[1];
                parsIWFId[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@iIssueNumber",
                    Value = iIssueNumber
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDispositionWFID", parsIWFId);
                //using (var conIWFId = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(conIWFId, CommandType.StoredProcedure, "usp_ISM_GetDispositionWFID", parsIWFId);
                //}
                return _ds;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region--GetGroupWithNoOfUsers
        //usp_ISM_GetGroupWithNoOfUsers
        public DataTable GetGroupWithNoOfUsers(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVSId",
                    Value = iVSId
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetGroupWithNoOfUsers",pars);
                return _ds.Tables[0];
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_Get_Group_Users
        public DataTable GetGroupUsers(int iGroupID)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@iGroupID",
                    Value = iGroupID
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_Get_Group_Users", pars);
                //using (var conIWFId = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(conIWFId, CommandType.StoredProcedure, "usp_ISM_Get_Group_Users", pars);
                //}
                return _ds.Tables[0];
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region--RegistrationCCEmails    
        public DataTable GetRegistration_CCMails(int iSBUVS)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iSBUVS",
                    Value = iSBUVS
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetRegistration_CCMails", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        public DataTable GetDashboardAgingIssues(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = iUserId
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardAgingIssues", pars);
                return _ds.Tables[0];
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetDashboardStackChart(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = iUserId
                };

                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardStackChart", pars);
                return _ds.Tables[0];
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetDashboardFunctionWiseChart(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = iUserId
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardFunctionWiseChart", pars);
                return _ds.Tables[0];
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetDashboardDonutChart(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = iUserId
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardDonutChart", pars);
                return _ds.Tables[0];
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_GetAgedTicketsByCategory
        public DataTable GetAgedTicketsByCategory(int icategory, int iVSId)
        {
            try
            {
                var pars = new SqlParameter[2];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@icategory",
                    Value = icategory
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVSId",
                    Value = iVSId
                };

                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetAgedTicketsByCategory", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetDashboardStackChartByProduct(string productlist)
        {
            try
            {
                string productlistTrim = productlist.Trim();
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar,
                    ParameterName = "@productlist",
                    Value = productlistTrim
                };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardStackChartByProduct", pars);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDashboardStackChartByProduct", pars);
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //usp_ISM_GetDashboardStackChartByProduct
        //public DataTable GetDashboardStackChartByProduct(Stackchartproducts req)
        //{
        //    try
        //    {
        //        var pars = new SqlParameter[10];
        //        pars[0] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p1",
        //            Value = req.p1
        //        };
        //        pars[1] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p2",
        //            Value = req.p2
        //        };
        //        pars[2] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p3",
        //            Value = req.p3
        //        };
        //        pars[3] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p4",
        //            Value = req.p4
        //        };
        //        pars[4] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p5",
        //            Value = req.p5
        //        };
        //        pars[5] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p6",
        //            Value = req.p6
        //        };
        //        pars[6] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p7",
        //            Value = req.p7
        //        };
        //        pars[7] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p8",
        //            Value = req.p8
        //        };
        //        pars[8] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p9",
        //            Value = req.p9
        //        };
        //        pars[9] = new SqlParameter
        //        {
        //            SqlDbType = SqlDbType.Int,
        //            ParameterName = "@p10",
        //            Value = req.p10
        //        };

        //        using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
        //        {
        //            _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDashboardStackChartByProduct", pars);
        //        }
        //        _dt = _ds.Tables[0];
        //        return _dt;
        //    }
        //    catch (CollinsPLMException exception)
        //    {
        //        LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
        //        throw;
        //    }
        //    catch (Exception exception)
        //    {
        //        LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
        //        throw;
        //    }
        //}

        /// <summary>
        /// GetPartNumber
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllPartNumber()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT iPartNumberID, vcPartNumberName  FROM tbl_ISM_PartNumber where bIsActive =1");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "SELECT iPartNumberID, vcPartNumberName  FROM tbl_ISM_PartNumber where bIsActive =1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_GetPartnumberBasedOnMultipleProductLines
        public DataTable GetPartnumberBasedOnMultipleProductLines(string iProductLineID, int iVSid)
        {
            try
            {
                var pars = new SqlParameter[2];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iProductLineID", Value = iProductLineID };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVSid", Value = iVSid };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetPartnumberBasedOnMultipleProductLines", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //usp_ISM_GetDashboardStackChartByProductDate
        public DataTable GetDashboardStackChartByProductDate(string productlist, string startdate, string enddate)
        {
            try
            {
                var pars = new SqlParameter[3];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@productlist", Value = productlist };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@startdate", Value = startdate };
                pars[2] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@enddate", Value = enddate };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardStackChartByProductDate", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDashboardStackChartByProductDate", pars);
                //}

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_GetDashboardStackChartBypartNumber
        public DataTable GetDashboardStackChartBypartNumber(string partidList, string startdate, string enddate)
        {
            try
            {
                var pars = new SqlParameter[3];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@partidList", Value = partidList };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@startdate", Value = startdate };
                pars[2] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@enddate", Value = enddate };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardStackChartBypartNumber", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDashboardStackChartBypartNumber", pars);
                //}

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable TestGraph()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select [Priority], Q1, Q2, Q3, Q4 from Test_Priority");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select [Priority], Q1, Q2, Q3, Q4 from Test_Priority");
                //    //_ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "select[Quater], [Line stopage], [Test failure], [Aesthetic issues], [Assembly issues],Test,Test2 from Test_Priority2");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetDashboardMultipLineChart(Linegraphproperties req)
        {
            try
            {
                var pars = new SqlParameter[10];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@productlist", Value = req.productlist == null ? "" : req.productlist };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@pnList", Value = req.pnList == null ? "" : req.pnList };
                pars[2] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@Priority", Value = req.Priority == null ? "" : req.Priority };
                pars[3] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@WFList", Value = req.WFList == null ? "" : req.WFList };
                pars[4] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@DispositionList", Value = req.DispositionList == null ? "" : req.DispositionList };
                pars[5] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@Quarterwise", Value = req.Quarterwise == null ? 0 : req.Quarterwise };
                pars[6] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@dStartDate", Value = req.dStartDate == "NaN-NaN-NaN" ? "" : req.dStartDate };
                pars[7] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@dEndDate", Value = req.dEndDate == "NaN-NaN-NaN" ? "" : req.dEndDate };
                pars[8] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@Quarter", Value = req.Quarter == null ? "" : req.Quarter };
                pars[9] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVSid", Value = req.iVSid };


                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardMultipLineChart", pars);
                if (_ds.Tables.Count > 0)
                    _dt = _ds.Tables[0];

                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetDashboardMultipLineChartExport(Linegraphproperties req)
        {
            try
            {
                var pars = new SqlParameter[9];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@productlist", Value = req.productlist == null ? "" : req.productlist };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@pnList", Value = req.pnList == null ? "" : req.pnList };
                pars[2] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@Priority", Value = req.Priority == "Choose" ? "" : req.Priority };
                pars[3] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@WFList", Value = req.WFList == null ? "" : req.WFList };
                pars[4] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@DispositionList", Value = req.DispositionList == null ? "" : req.DispositionList };
                pars[5] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@Quarterwise", Value = req.Quarterwise == null ? 0 : req.Quarterwise };
                pars[6] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@dStartDate", Value = req.dStartDate == "NaN-NaN-NaN" ? "" : req.dStartDate };
                pars[7] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@dEndDate", Value = req.dEndDate == "NaN-NaN-NaN" ? "" : req.dEndDate };
                pars[8] = new SqlParameter { SqlDbType = SqlDbType.NVarChar, ParameterName = "@Quarter", Value = req.Quarter == null ? "" : req.Quarter };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardExportData", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetDashboardExportData", pars);
                //}
                if (_ds.Tables.Count > 0)
                    _dt = _ds.Tables[0];

                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetAllDispositions()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT iDispositionTypeID,vcDispositionName FROM tbl_ISM_DipositionType where bStatus=1");
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.Text, "SELECT iDispositionTypeID,vcDispositionName FROM tbl_ISM_DipositionType where bStatus=1");
                //}
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //usp_ISM_ManageWorkflowDispositions
        public DataTable ManageWorkflowDispositions(int iVSid)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVSid", Value = iVSid };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_ManageWorkflowDispositions", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_GetWorkflowDispositions
        public DataTable GetWorkflowDispositions(int iWorkFlowID, int iVSId)
        {
            try
            {
                var pars = new SqlParameter[2];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iWorkFlowID", Value = iWorkFlowID };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetWorkflowDispositions", pars);
                //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_ISM_GetWorkflowDispositions", pars);
                //}

                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_InsertWorkflowDisposition
        public int InsertWorkflowDisposition(int iWorkFlowID, string vcDispositionName, int iCreatedBy, string vcDPAlias)
        {
            try
            {
                var pars = new SqlParameter[5];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iWorkFlowID",
                    Value = iWorkFlowID
                };
                pars[1] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcDispositionName",
                    Value = vcDispositionName
                };
                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iCreatedBy",
                    Value = iCreatedBy
                };
                pars[3] = new SqlParameter
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcDPAlias",
                    Value = vcDPAlias
                };
                pars[4] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };
                int result;
                int returnValue;
                result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_InsertWorkflowDisposition", pars));
                returnValue = Convert.ToInt32(pars[4].Value);
                //using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                //{
                //    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertWorkflowDisposition", pars));
                //    returnValue = Convert.ToInt32(pars[4].Value);
                //}
                return returnValue;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetEmailsForInitiator_LastprocessedUser(int iIssueNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueNumber", Value = iIssueNumber };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetEmailsForInitiator_LastprocessedUser", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_GetDashboardTopCount_details
        public DataTable GetDashboardTopCount_details(int iUserId, int icategory, int month)
        {
            try
            {
                var pars = new SqlParameter[3];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iUserId", Value = iUserId };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@icategory", Value = icategory };
                pars[2] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@month", Value = month };
                
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDashboardTopCount_details", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //Evacs enhancements
        public DataTable GetSBU()
        {
            try
            {
                string sp = string.Empty;
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetSBU");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetValueStreams(int iSBUId)
        {
            try
            {
                var pars = new SqlParameter[1];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iSBUId", Value = iSBUId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetValueStreams", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //usp_ISM_GroupsBasedOnVS
        public DataTable GroupsBasedOnVS(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GroupsBasedOnVS", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_GetDispositionDescription
        public DataTable GetDispositionDescription(int iIssueWFID)
        {
            try
            {
                var pars = new SqlParameter[1];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueWFID", Value = iIssueWFID };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetDispositionDescription", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        //usp_ISM_GetCRCODeatails
        public DataTable GetCRCODeatails(int iIssueNumber)
        {
            try
            {
                var pars = new SqlParameter[1];
                string sp = string.Empty;
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iIssueNumber", Value = iIssueNumber };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetCRCODeatails", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetCategoriesBasedVS(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetCategoriesBasedVS", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetCategorById(int iWorkFlowID)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iWorkFlowID", Value = iWorkFlowID };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_GetCategorById", pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable IssuesBasedOnValueStream(int iVSId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSId", Value = iVSId };
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_ISM_IssuesBasedOnValueStream",pars);
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public bool UpdateCategorByWorkFlowID(WFObj req)
        {
            try
            {
                var pars = new SqlParameter[4];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iWorkFlowID", Value = req.iWorkFlowID };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@vcWorkFlowName", Value = req.vcWorkFlowName };
                pars[2] = new SqlParameter { SqlDbType = SqlDbType.Int, ParameterName = "@iCreatedBy", Value = req.iUserId };
                pars[3] = new SqlParameter() { SqlDbType = SqlDbType.Int, ParameterName = "@ReturnValue", Direction = ParameterDirection.Output };
                int returnValue;
                int executedVal;
                executedVal = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_UpdateCategorByWorkFlowID", pars));
                returnValue = Convert.ToInt32(pars[3].Value);
                _status = returnValue == 1;
                return _status;

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool CheckWFExistance(WFObj req)
        {
            try
            {
                var pars = new SqlParameter[3];
                pars[0] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@vcWorkFlowName", Value = req.vcWorkFlowName };
                pars[1] = new SqlParameter { SqlDbType = SqlDbType.VarChar, ParameterName = "@iVSid", Value = req.iVSId };
                pars[2] = new SqlParameter() { SqlDbType = SqlDbType.Int, ParameterName = "@ReturnValue", Direction = ParameterDirection.Output };
                int returnValue;
                int executedVal;
                executedVal = Convert.ToInt32(SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_ISM_CheckWFExistance", pars));
                returnValue = Convert.ToInt32(pars[2].Value);
                _status = returnValue == 1;
                return _status;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool InsertCategories(WFObj ctreq)
        {
            try
            {
                var pars = new SqlParameter[5];

                pars[0] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.NVarChar,
                    ParameterName = "@vcWorkFlowName",
                    Value = ctreq.vcWorkFlowName
                };
                pars[1] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@bStatus",
                    Value = ctreq.bStatus
                };
                pars[2] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iUserId",
                    Value = ctreq.iUserId
                };
                pars[3] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@iVSId",
                    Value = ctreq.iVSId
                };
                pars[4] = new SqlParameter()
                {
                    SqlDbType = SqlDbType.Int,
                    ParameterName = "@ReturnValue",
                    Direction = ParameterDirection.Output
                };

                int result;
                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    result = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "usp_ISM_InsertCategories", pars));
                    returnValue = Convert.ToInt32(pars[4].Value);
                }
                _status = returnValue == 1;
                return _status;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //Mathu
        public DataTable GetLOVALLValueStream()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iVSId,vcVS from tbl_ISM_ValueStream");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public DataTable GetLOVALLSBU()
        {
            try
            {
                _ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "select iSBUId,vcSBUName from tbl_ISM_SBU");
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
